# SakaNect - Agricultural Marketplace Platform

## Overview

SakaNect is a full-stack web application designed to connect farmers and buyers in the Philippines. The platform facilitates direct trade relationships, supporting sales, barter, and donation transactions for agricultural products. Built with modern web technologies, it provides a seamless experience for both farmers listing their crops and buyers searching for fresh produce.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter for client-side routing
- **State Management**: TanStack Query (React Query) for server state management
- **UI Framework**: shadcn/ui components built on Radix UI primitives
- **Styling**: Tailwind CSS with custom design tokens
- **Forms**: React Hook Form with Zod validation
- **Build Tool**: Vite for development and production builds

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **Authentication**: Replit Auth with OpenID Connect
- **Session Management**: Express sessions with PostgreSQL storage
- **Database Layer**: Drizzle ORM with Neon serverless PostgreSQL
- **API Pattern**: RESTful API with comprehensive error handling

### Database Design
- **Primary Database**: PostgreSQL (Neon serverless)
- **ORM**: Drizzle ORM with type-safe queries
- **Schema Management**: Drizzle Kit for migrations
- **Key Tables**:
  - Users (farmers and buyers)
  - Crops (product listings)
  - Crop Requests (buyer inquiries)
  - Messages (communication)
  - Sessions (authentication)

## Key Components

### Authentication System
- **Provider**: Replit Auth integration
- **Session Storage**: PostgreSQL-backed sessions
- **User Roles**: Farmer and Buyer role-based access
- **Security**: HTTPS-only cookies, CSRF protection

### Crop Management
- **Listing Creation**: Farmers can create detailed crop listings
- **Transaction Types**: Support for sales, barter, and donations
- **Status Tracking**: Available, limited, sold status management
- **Search & Filter**: Category, location, and text-based filtering

### Request System
- **Buyer Inquiries**: Structured request system for crop purchases
- **Communication**: Built-in messaging between farmers and buyers
- **Status Management**: Pending, approved, declined, completed, cancelled states

### Real-time Features
- **Live Updates**: React Query for automatic data synchronization
- **Notifications**: Toast-based user feedback system
- **Responsive Design**: Mobile-first responsive layout

## Data Flow

1. **User Authentication**: Replit Auth → Session Creation → User Profile Setup
2. **Crop Listing**: Farmer Input → Validation → Database Storage → Search Index
3. **Crop Discovery**: Search Filters → Database Query → Paginated Results
4. **Purchase Process**: Buyer Request → Farmer Notification → Negotiation → Transaction
5. **Communication**: Message Creation → Database Storage → Real-time Updates

## External Dependencies

### Authentication
- **Replit Auth**: Primary authentication provider
- **OpenID Connect**: Standard authentication protocol

### Database
- **Neon**: Serverless PostgreSQL hosting
- **Connection Pooling**: Neon's built-in connection management

### UI Components
- **Radix UI**: Accessible component primitives
- **Lucide React**: Icon library
- **React Hook Form**: Form management
- **Recharts**: Data visualization (for insights)

### Development Tools
- **Vite**: Build tool and dev server
- **ESBuild**: Production bundling
- **TypeScript**: Type safety across the stack

## Deployment Strategy

### Development Environment
- **Platform**: Replit with auto-reload
- **Port Configuration**: Port 5000 with external mapping
- **Hot Reload**: Vite HMR for frontend, nodemon equivalent for backend

### Production Build
- **Frontend**: Vite build to `dist/public`
- **Backend**: ESBuild bundling to `dist/index.js`
- **Static Serving**: Express serves built frontend assets
- **Process Management**: Single Node.js process handling both API and static files

### Database Management
- **Migrations**: Drizzle Kit push for schema updates
- **Environment Variables**: DATABASE_URL for connection string
- **Session Storage**: PostgreSQL table for Express sessions

## Changelog

```
Changelog:
- June 14, 2025. Initial setup
```

## User Preferences

```
Preferred communication style: Simple, everyday language.
```