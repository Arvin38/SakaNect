import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import Navigation from "@/components/navigation";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { 
  History as HistoryIcon, 
  Search, 
  Calendar,
  Download,
  Filter,
  CheckCircle,
  XCircle,
  Clock,
  AlertCircle,
  DollarSign,
  ArrowRightLeft,
  Heart,
  MapPin,
  User
} from "lucide-react";
import { cn } from "@/lib/utils";

export default function History() {
  const { user, isAuthenticated, isLoading: authLoading } = useAuth();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("pending");
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("");
  const [dateFilter, setDateFilter] = useState("");

  // Redirect if not authenticated
  useEffect(() => {
    if (!authLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, authLoading, toast]);

  const { data: allRequests, isLoading } = useQuery({
    queryKey: ["/api/crop-requests"],
    retry: false,
  });

  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-sakanect-green"></div>
      </div>
    );
  }

  if (!user) return null;

  const isFarmer = user.role === 'farmer';

  // Filter transactions based on active tab and search
  const filteredHistory = allRequests?.filter((request: any) => {
    // Tab filter
    if (activeTab !== "all" && request.status !== activeTab) return false;
    
    // Search filter
    if (searchTerm) {
      const searchLower = searchTerm.toLowerCase();
      const cropName = request.crop?.name?.toLowerCase() || '';
      const farmerName = `${request.farmer?.firstName} ${request.farmer?.lastName}`.toLowerCase();
      const buyerName = `${request.buyer?.firstName} ${request.buyer?.lastName}`.toLowerCase();
      
      if (!cropName.includes(searchLower) && !farmerName.includes(searchLower) && !buyerName.includes(searchLower)) {
        return false;
      }
    }
    
    // Status filter
    if (statusFilter && request.status !== statusFilter) return false;
    
    // Date filter
    if (dateFilter) {
      const requestDate = new Date(request.createdAt).toISOString().split('T')[0];
      if (requestDate !== dateFilter) return false;
    }
    
    return true;
  }) || [];

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'pending':
        return <Clock className="w-4 h-4 text-yellow-500" />;
      case 'approved':
        return <CheckCircle className="w-4 h-4 text-sakanect-green" />;
      case 'completed':
        return <CheckCircle className="w-4 h-4 text-blue-500" />;
      case 'declined':
        return <XCircle className="w-4 h-4 text-red-500" />;
      case 'cancelled':
        return <AlertCircle className="w-4 h-4 text-gray-500" />;
      default:
        return <Clock className="w-4 h-4" />;
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'pending':
        return <Badge className="bg-yellow-500 text-white">Pending</Badge>;
      case 'approved':
        return <Badge className="bg-sakanect-green text-white">Approved</Badge>;
      case 'completed':
        return <Badge className="bg-blue-500 text-white">Completed</Badge>;
      case 'declined':
        return <Badge className="bg-red-500 text-white">Declined</Badge>;
      case 'cancelled':
        return <Badge variant="secondary">Cancelled</Badge>;
      default:
        return <Badge variant="secondary">{status}</Badge>;
    }
  };

  const getTransactionIcon = (type: string) => {
    switch (type) {
      case 'sale':
        return <DollarSign className="w-4 h-4 text-green-600" />;
      case 'barter':
        return <ArrowRightLeft className="w-4 h-4 text-blue-600" />;
      case 'donation':
        return <Heart className="w-4 h-4 text-purple-600" />;
      default:
        return <DollarSign className="w-4 h-4" />;
    }
  };

  const getStatusCounts = () => {
    if (!allRequests) return {};
    
    return allRequests.reduce((acc: any, request: any) => {
      acc[request.status] = (acc[request.status] || 0) + 1;
      return acc;
    }, {});
  };

  const statusCounts = getStatusCounts();

  return (
    <div className="min-h-screen bg-gray-50">
      <Navigation />
      
      <div className="lg:ml-64">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {/* Page Header */}
          <Card className="mb-8">
            <CardHeader>
              <CardTitle className="text-2xl font-bold text-gray-900 flex items-center">
                <HistoryIcon className="w-6 h-6 mr-2 text-sakanect-green" />
                Transaction History
              </CardTitle>
              <p className="text-gray-600">
                View and manage all your transaction history with detailed filters
              </p>
            </CardHeader>
          </Card>

          {/* Search and Filters */}
          <Card className="mb-6">
            <CardContent className="p-6">
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                  <Input
                    type="text"
                    placeholder="Search transactions..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
                
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger>
                    <SelectValue placeholder="All Status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="">All Status</SelectItem>
                    <SelectItem value="pending">Pending</SelectItem>
                    <SelectItem value="approved">Approved</SelectItem>
                    <SelectItem value="completed">Completed</SelectItem>
                    <SelectItem value="declined">Declined</SelectItem>
                    <SelectItem value="cancelled">Cancelled</SelectItem>
                  </SelectContent>
                </Select>

                <Input
                  type="date"
                  value={dateFilter}
                  onChange={(e) => setDateFilter(e.target.value)}
                  placeholder="Filter by date"
                />

                <Button variant="outline" className="flex items-center">
                  <Download className="w-4 h-4 mr-2" />
                  Export
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Status Filter Tabs */}
          <Tabs value={activeTab} onValueChange={setActiveTab} className="mb-6">
            <TabsList className="grid w-full grid-cols-5">
              <TabsTrigger value="pending" className="flex items-center space-x-2">
                <span>Pending</span>
                {statusCounts.pending && (
                  <Badge variant="secondary" className="ml-1 bg-yellow-500 text-white">
                    {statusCounts.pending}
                  </Badge>
                )}
              </TabsTrigger>
              <TabsTrigger value="completed" className="flex items-center space-x-2">
                <span>Completed</span>
                {statusCounts.completed && (
                  <Badge variant="secondary" className="ml-1 bg-blue-500 text-white">
                    {statusCounts.completed}
                  </Badge>
                )}
              </TabsTrigger>
              <TabsTrigger value="declined" className="flex items-center space-x-2">
                <span>Declined</span>
                {statusCounts.declined && (
                  <Badge variant="secondary" className="ml-1 bg-red-500 text-white">
                    {statusCounts.declined}
                  </Badge>
                )}
              </TabsTrigger>
              <TabsTrigger value="cancelled" className="flex items-center space-x-2">
                <span>Cancelled</span>
                {statusCounts.cancelled && (
                  <Badge variant="secondary" className="ml-1">
                    {statusCounts.cancelled}
                  </Badge>
                )}
              </TabsTrigger>
              <TabsTrigger value="all">All</TabsTrigger>
            </TabsList>

            <TabsContent value={activeTab} className="mt-6">
              {isLoading ? (
                <div className="space-y-4">
                  {[...Array(5)].map((_, i) => (
                    <Card key={i}>
                      <CardContent className="p-6">
                        <div className="flex items-center space-x-4">
                          <Skeleton className="h-16 w-16 rounded-lg" />
                          <div className="flex-1">
                            <Skeleton className="h-5 w-32 mb-2" />
                            <Skeleton className="h-4 w-48 mb-2" />
                            <Skeleton className="h-4 w-36" />
                          </div>
                          <Skeleton className="h-6 w-20" />
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              ) : filteredHistory.length > 0 ? (
                <div className="space-y-4">
                  {filteredHistory.map((request: any) => (
                    <Card key={request.id} className="hover:shadow-md transition-shadow">
                      <CardContent className="p-6">
                        <div className="flex flex-col lg:flex-row lg:items-center space-y-4 lg:space-y-0 lg:space-x-6">
                          {/* Transaction Info */}
                          <div className="flex items-center space-x-4 flex-1">
                            {/* Crop Image */}
                            {request.crop?.imageUrl && (
                              <img 
                                className="h-16 w-16 rounded-lg object-cover" 
                                src={request.crop.imageUrl} 
                                alt={request.crop.name}
                                onError={(e) => {
                                  const target = e.target as HTMLImageElement;
                                  target.style.display = 'none';
                                }}
                              />
                            )}
                            
                            {/* Transaction Details */}
                            <div className="flex-1">
                              <div className="flex items-center space-x-2 mb-2">
                                {getTransactionIcon(request.transactionType)}
                                <h3 className="font-semibold text-gray-900">{request.crop?.name}</h3>
                                <Badge variant="outline" className="text-xs">
                                  {request.transactionType}
                                </Badge>
                              </div>
                              
                              <div className="text-sm text-gray-600 space-y-1">
                                <p>
                                  {request.transactionType === 'sale' ? (
                                    <>₱{request.offeredPrice} per {request.crop?.unit}</>
                                  ) : request.transactionType === 'barter' ? (
                                    <>Trade for: {request.barterOffer || 'Items'}</>
                                  ) : (
                                    <>Free Donation</>
                                  )}
                                  <span className="ml-2">• {request.requestedQuantity} {request.crop?.unit}</span>
                                </p>
                                
                                <div className="flex items-center space-x-4">
                                  <span className="flex items-center">
                                    <User className="w-3 h-3 mr-1" />
                                    {isFarmer 
                                      ? `${request.buyer?.firstName} ${request.buyer?.lastName || ''}`.trim()
                                      : `${request.farmer?.firstName} ${request.farmer?.lastName || ''}`.trim()
                                    }
                                  </span>
                                  
                                  <span className="flex items-center">
                                    <MapPin className="w-3 h-3 mr-1" />
                                    {request.crop?.location}
                                  </span>
                                  
                                  <span className="flex items-center">
                                    <Calendar className="w-3 h-3 mr-1" />
                                    {new Date(request.createdAt).toLocaleDateString()}
                                  </span>
                                </div>
                              </div>
                            </div>
                          </div>

                          {/* User Avatar */}
                          <div className="flex items-center space-x-3">
                            <Avatar className="h-12 w-12">
                              <AvatarImage 
                                src={isFarmer ? request.buyer?.profileImageUrl : request.farmer?.profileImageUrl} 
                                alt="User" 
                              />
                              <AvatarFallback>
                                {isFarmer 
                                  ? request.buyer?.firstName?.[0]?.toUpperCase() 
                                  : request.farmer?.firstName?.[0]?.toUpperCase()
                                }
                              </AvatarFallback>
                            </Avatar>
                          </div>

                          {/* Status and Total */}
                          <div className="flex flex-col items-end space-y-2">
                            <div className="flex items-center space-x-2">
                              {getStatusIcon(request.status)}
                              {getStatusBadge(request.status)}
                            </div>
                            
                            {request.transactionType === 'sale' && request.offeredPrice && (
                              <div className="text-right">
                                <p className="text-sm text-gray-500">Total</p>
                                <p className="font-semibold text-sakanect-green">
                                  ₱{(parseFloat(request.offeredPrice) * request.requestedQuantity).toFixed(2)}
                                </p>
                              </div>
                            )}
                          </div>
                        </div>

                        {/* Additional Notes */}
                        {request.notes && (
                          <div className="mt-4 p-3 bg-gray-50 rounded-lg">
                            <p className="text-sm text-gray-700">
                              <span className="font-medium">Notes:</span> {request.notes}
                            </p>
                          </div>
                        )}

                        {/* Timeline for completed transactions */}
                        {request.status === 'completed' && (
                          <div className="mt-4 pt-4 border-t border-gray-200">
                            <div className="flex items-center space-x-4 text-sm text-gray-500">
                              <span className="flex items-center">
                                <CheckCircle className="w-4 h-4 mr-1 text-green-500" />
                                Request Created: {new Date(request.createdAt).toLocaleDateString()}
                              </span>
                              <span className="flex items-center">
                                <CheckCircle className="w-4 h-4 mr-1 text-green-500" />
                                Completed: {new Date(request.updatedAt).toLocaleDateString()}
                              </span>
                            </div>
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  ))}
                </div>
              ) : (
                <Card>
                  <CardContent className="p-12 text-center">
                    <div className="mb-4">
                      <HistoryIcon className="text-gray-400 text-6xl mx-auto mb-4" />
                      <h3 className="text-xl font-semibold text-gray-900 mb-2">
                        No {activeTab === 'all' ? '' : activeTab} transactions found
                      </h3>
                      <p className="text-gray-600">
                        {searchTerm || statusFilter || dateFilter
                          ? "Try adjusting your filters to see more results"
                          : "Your transaction history will appear here as you complete trades"
                        }
                      </p>
                    </div>
                    
                    {(searchTerm || statusFilter || dateFilter) && (
                      <Button
                        variant="outline"
                        onClick={() => {
                          setSearchTerm("");
                          setStatusFilter("");
                          setDateFilter("");
                        }}
                        className="mt-4"
                      >
                        Clear Filters
                      </Button>
                    )}
                  </CardContent>
                </Card>
              )}
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}
