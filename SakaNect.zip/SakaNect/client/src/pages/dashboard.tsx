import { useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import Navigation from "@/components/navigation";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Sprout, Clock, DollarSign, Plus, Edit, Trash2, MapPin, User } from "lucide-react";
import CropFormModal from "@/components/crop-form-modal";
import { useState } from "react";

export default function Dashboard() {
  const { user, isAuthenticated, isLoading: authLoading } = useAuth();
  const { toast } = useToast();
  const [showCropForm, setShowCropForm] = useState(false);

  // Redirect if not authenticated
  useEffect(() => {
    if (!authLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, authLoading, toast]);

  const { data: stats, isLoading: statsLoading } = useQuery({
    queryKey: ["/api/dashboard/stats"],
    retry: false,
  });

  const { data: crops, isLoading: cropsLoading } = useQuery({
    queryKey: ["/api/crops", { farmerId: user?.id, limit: 10 }],
    retry: false,
    enabled: user?.role === 'farmer',
  });

  const { data: requests, isLoading: requestsLoading } = useQuery({
    queryKey: ["/api/crop-requests", { status: 'pending', limit: 5 }],
    retry: false,
  });

  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-sakanect-green"></div>
      </div>
    );
  }

  if (!user) return null;

  const isFarmer = user.role === 'farmer';

  return (
    <div className="min-h-screen bg-gray-50">
      <Navigation />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Main Content */}
          <div className="flex-1">
            {/* Welcome Message */}
            <Card className="mb-8">
              <CardContent className="pt-6">
                <h2 className="text-2xl font-bold text-gray-900 mb-2">
                  Hi {user.firstName || 'there'}! Dashboard
                </h2>
                <p className="text-gray-600">
                  {isFarmer 
                    ? "Manage your crops and track your sales performance" 
                    : "Browse crops and track your purchases"}
                </p>
              </CardContent>
            </Card>

            {/* Stats Cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
              {isFarmer ? (
                <>
                  <Card>
                    <CardContent className="pt-6">
                      <div className="flex items-center">
                        <div className="flex-shrink-0">
                          <div className="w-12 h-12 bg-sakanect-green bg-opacity-20 rounded-lg flex items-center justify-center">
                            <Sprout className="text-sakanect-green text-xl" />
                          </div>
                        </div>
                        <div className="ml-4">
                          <p className="text-sm font-medium text-gray-600">Active Crops</p>
                          {statsLoading ? (
                            <Skeleton className="h-8 w-16" />
                          ) : (
                            <p className="text-2xl font-bold text-gray-900">{stats?.activeCrops || 0}</p>
                          )}
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardContent className="pt-6">
                      <div className="flex items-center">
                        <div className="flex-shrink-0">
                          <div className="w-12 h-12 bg-yellow-500 bg-opacity-20 rounded-lg flex items-center justify-center">
                            <Clock className="text-yellow-500 text-xl" />
                          </div>
                        </div>
                        <div className="ml-4">
                          <p className="text-sm font-medium text-gray-600">Pending Requests</p>
                          {statsLoading ? (
                            <Skeleton className="h-8 w-16" />
                          ) : (
                            <p className="text-2xl font-bold text-gray-900">{stats?.pendingRequests || 0}</p>
                          )}
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardContent className="pt-6">
                      <div className="flex items-center">
                        <div className="flex-shrink-0">
                          <div className="w-12 h-12 bg-blue-500 bg-opacity-20 rounded-lg flex items-center justify-center">
                            <DollarSign className="text-blue-500 text-xl" />
                          </div>
                        </div>
                        <div className="ml-4">
                          <p className="text-sm font-medium text-gray-600">Total Sales</p>
                          {statsLoading ? (
                            <Skeleton className="h-8 w-24" />
                          ) : (
                            <p className="text-2xl font-bold text-gray-900">₱{stats?.totalSales?.toLocaleString() || 0}</p>
                          )}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </>
              ) : (
                <>
                  <Card>
                    <CardContent className="pt-6">
                      <div className="flex items-center">
                        <div className="flex-shrink-0">
                          <div className="w-12 h-12 bg-yellow-500 bg-opacity-20 rounded-lg flex items-center justify-center">
                            <Clock className="text-yellow-500 text-xl" />
                          </div>
                        </div>
                        <div className="ml-4">
                          <p className="text-sm font-medium text-gray-600">Pending Requests</p>
                          {statsLoading ? (
                            <Skeleton className="h-8 w-16" />
                          ) : (
                            <p className="text-2xl font-bold text-gray-900">{stats?.pendingRequests || 0}</p>
                          )}
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardContent className="pt-6">
                      <div className="flex items-center">
                        <div className="flex-shrink-0">
                          <div className="w-12 h-12 bg-blue-500 bg-opacity-20 rounded-lg flex items-center justify-center">
                            <DollarSign className="text-blue-500 text-xl" />
                          </div>
                        </div>
                        <div className="ml-4">
                          <p className="text-sm font-medium text-gray-600">Total Purchases</p>
                          {statsLoading ? (
                            <Skeleton className="h-8 w-24" />
                          ) : (
                            <p className="text-2xl font-bold text-gray-900">₱{stats?.totalPurchases?.toLocaleString() || 0}</p>
                          )}
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardContent className="pt-6">
                      <div className="flex items-center">
                        <div className="flex-shrink-0">
                          <div className="w-12 h-12 bg-sakanect-green bg-opacity-20 rounded-lg flex items-center justify-center">
                            <Sprout className="text-sakanect-green text-xl" />
                          </div>
                        </div>
                        <div className="ml-4">
                          <p className="text-sm font-medium text-gray-600">Available Crops</p>
                          <p className="text-2xl font-bold text-gray-900">-</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </>
              )}
            </div>

            {/* Main Content Grid */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              {/* Pending Requests */}
              <Card>
                <CardHeader>
                  <CardTitle>
                    {isFarmer ? "Pending Crop Requests" : "My Recent Requests"}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {requestsLoading ? (
                    <div className="space-y-4">
                      {[...Array(3)].map((_, i) => (
                        <div key={i} className="flex items-center space-x-4 p-4 border border-gray-200 rounded-lg">
                          <Skeleton className="h-12 w-12 rounded-lg" />
                          <div className="flex-1">
                            <Skeleton className="h-4 w-24 mb-2" />
                            <Skeleton className="h-3 w-32 mb-1" />
                            <Skeleton className="h-3 w-28" />
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : requests && requests.length > 0 ? (
                    <div className="space-y-4">
                      {requests.slice(0, 3).map((request: any) => (
                        <div key={request.id} className="flex items-center space-x-4 p-4 border border-gray-200 rounded-lg">
                          {request.crop?.imageUrl && (
                            <img 
                              className="h-12 w-12 rounded-lg object-cover" 
                              src={request.crop.imageUrl} 
                              alt={request.crop.name} 
                            />
                          )}
                          <div className="flex-1">
                            <h4 className="font-medium text-gray-900">{request.crop?.name}</h4>
                            <p className="text-sm text-gray-600">
                              {isFarmer ? request.buyer?.firstName : request.farmer?.firstName} • 
                              ₱{request.offeredPrice} per {request.crop?.unit} • 
                              {request.requestedQuantity} {request.crop?.unit}
                            </p>
                            <p className="text-xs text-gray-500 flex items-center">
                              <MapPin className="w-3 h-3 mr-1" />
                              {request.crop?.location}
                            </p>
                          </div>
                          <div className="flex space-x-2">
                            <Badge variant="secondary">{request.status}</Badge>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-gray-500 text-center py-8">No pending requests</p>
                  )}
                  
                  <div className="text-center pt-4">
                    <Button variant="ghost" className="text-sakanect-green">
                      View All Requests
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* Crop Listings (for farmers) or Browse Crops (for buyers) */}
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle>
                    {isFarmer ? "My Crop Listings" : "Recent Crops"}
                  </CardTitle>
                  {isFarmer && (
                    <Button 
                      onClick={() => setShowCropForm(true)}
                      className="bg-sakanect-green text-white hover:bg-sakanect-dark"
                      size="sm"
                    >
                      <Plus className="w-4 h-4 mr-2" />
                      Add Crop
                    </Button>
                  )}
                </CardHeader>
                <CardContent>
                  {cropsLoading ? (
                    <div className="space-y-4">
                      {[...Array(3)].map((_, i) => (
                        <div key={i} className="border border-gray-200 rounded-lg p-4">
                          <div className="flex space-x-4">
                            <Skeleton className="h-20 w-20 rounded-lg" />
                            <div className="flex-1">
                              <Skeleton className="h-4 w-32 mb-2" />
                              <Skeleton className="h-3 w-24 mb-2" />
                              <Skeleton className="h-3 w-28 mb-2" />
                              <Skeleton className="h-3 w-20" />
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : crops && crops.length > 0 ? (
                    <div className="space-y-4">
                      {crops.slice(0, 3).map((crop: any) => (
                        <div key={crop.id} className="border border-gray-200 rounded-lg p-4">
                          <div className="flex space-x-4">
                            {crop.imageUrl && (
                              <img 
                                className="h-20 w-20 rounded-lg object-cover flex-shrink-0" 
                                src={crop.imageUrl} 
                                alt={crop.name} 
                              />
                            )}
                            <div className="flex-1 min-w-0">
                              <h4 className="font-semibold text-gray-900 mb-1">{crop.name}</h4>
                              <p className="text-sm text-gray-600 mb-2">
                                <span className="font-medium">₱{crop.price} per {crop.unit}</span> • 
                                <span> {crop.quantity} {crop.unit}</span>
                              </p>
                              <p className="text-xs text-gray-500 mb-2">{crop.description}</p>
                              <p className="text-xs text-gray-500 flex items-center">
                                <MapPin className="w-3 h-3 mr-1" />
                                {crop.location}
                              </p>
                              <div className="flex items-center mt-2 space-x-2">
                                <Badge 
                                  variant={crop.status === 'available' ? 'default' : 'secondary'}
                                  className={crop.status === 'available' ? 'bg-sakanect-green' : ''}
                                >
                                  {crop.status}
                                </Badge>
                                <Badge variant="outline">
                                  {crop.transactionType}
                                </Badge>
                              </div>
                            </div>
                            {isFarmer && (
                              <div className="flex flex-col space-y-2">
                                <Button variant="ghost" size="sm" className="text-sakanect-green">
                                  <Edit className="w-4 h-4" />
                                </Button>
                                <Button variant="ghost" size="sm" className="text-red-500">
                                  <Trash2 className="w-4 h-4" />
                                </Button>
                              </div>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-8">
                      <p className="text-gray-500 mb-4">
                        {isFarmer ? "No crops listed yet" : "No crops available"}
                      </p>
                      {isFarmer && (
                        <Button 
                          onClick={() => setShowCropForm(true)}
                          className="bg-sakanect-green text-white hover:bg-sakanect-dark"
                        >
                          <Plus className="w-4 h-4 mr-2" />
                          Add Your First Crop
                        </Button>
                      )}
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>

      {/* Crop Form Modal */}
      <CropFormModal 
        isOpen={showCropForm}
        onClose={() => setShowCropForm(false)}
      />
    </div>
  );
}
