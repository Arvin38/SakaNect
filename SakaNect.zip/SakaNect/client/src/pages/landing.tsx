import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Sprout, Handshake, MapPin } from "lucide-react";

export default function Landing() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Navigation */}
      <nav className="bg-white shadow-sm border-b border-gray-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <MapPin className="text-sakanect-green text-2xl mr-2" />
              <span className="text-2xl font-bold text-sakanect-green">SakaNect</span>
            </div>
            <div className="flex items-center space-x-4">
              <Button 
                onClick={() => window.location.href = '/api/login'}
                variant="outline"
                className="border-sakanect-green text-sakanect-green hover:bg-sakanect-green hover:text-white"
              >
                Sign In
              </Button>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="bg-gradient-to-br from-green-50 to-green-100 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <div className="mb-8">
              <MapPin className="text-sakanect-green text-6xl mb-4 mx-auto" />
              <h1 className="text-4xl md:text-6xl font-bold text-sakanect-green mb-4">SakaNect</h1>
              <p className="text-xl text-gray-600 mb-8">Connect farmers and buyers across the Philippines</p>
            </div>

            {/* Feature Cards */}
            <div className="grid md:grid-cols-3 gap-8 mb-12">
              <Card className="bg-gray-800 text-white">
                <CardContent className="p-8">
                  <Sprout className="text-yellow-400 text-4xl mb-4 mx-auto" />
                  <h3 className="text-xl font-semibold mb-3">Fresh Produce</h3>
                  <p className="text-gray-300">Direct from local farmers to your table</p>
                </CardContent>
              </Card>
              
              <Card className="bg-gray-800 text-white">
                <CardContent className="p-8">
                  <Handshake className="text-yellow-400 text-4xl mb-4 mx-auto" />
                  <h3 className="text-xl font-semibold mb-3">Fair Trade</h3>
                  <p className="text-gray-300">Connect directly and trade fairly</p>
                </CardContent>
              </Card>
              
              <Card className="bg-gray-800 text-white">
                <CardContent className="p-8">
                  <MapPin className="text-pink-400 text-4xl mb-4 mx-auto" />
                  <h3 className="text-xl font-semibold mb-3">Local Network</h3>
                  <p className="text-gray-300">Find suppliers and buyers in your area</p>
                </CardContent>
              </Card>
            </div>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
              <Button 
                onClick={() => window.location.href = '/api/login'}
                className="bg-sakanect-green text-white px-8 py-3 hover:bg-sakanect-dark"
                size="lg"
              >
                Get Started
              </Button>
              <Button 
                onClick={() => window.location.href = '/api/login'}
                variant="outline"
                className="border-sakanect-green text-sakanect-green px-8 py-3 hover:bg-sakanect-green hover:text-white"
                size="lg"
              >
                Learn More
              </Button>
            </div>

            <div className="mt-8">
              <p className="text-gray-600 mb-2">Join thousands of farmers and buyers</p>
              <p className="text-sm text-gray-500">Connecting Philippine agriculture</p>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Why Choose SakaNect?</h2>
            <p className="text-xl text-gray-600">Empowering agricultural communities through technology</p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="bg-sakanect-green bg-opacity-20 rounded-lg p-6 mb-4">
                <Sprout className="text-sakanect-green text-3xl mx-auto" />
              </div>
              <h3 className="text-lg font-semibold mb-2">Direct Trading</h3>
              <p className="text-gray-600">Connect directly with farmers and buyers, eliminating middlemen</p>
            </div>
            
            <div className="text-center">
              <div className="bg-sakanect-green bg-opacity-20 rounded-lg p-6 mb-4">
                <MapPin className="text-sakanect-green text-3xl mx-auto" />
              </div>
              <h3 className="text-lg font-semibold mb-2">Local Network</h3>
              <p className="text-gray-600">Find suppliers and customers in your local area</p>
            </div>
            
            <div className="text-center">
              <div className="bg-sakanect-green bg-opacity-20 rounded-lg p-6 mb-4">
                <Handshake className="text-sakanect-green text-3xl mx-auto" />
              </div>
              <h3 className="text-lg font-semibold mb-2">Fair Pricing</h3>
              <p className="text-gray-600">Transparent pricing that benefits both farmers and buyers</p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center mb-4">
                <MapPin className="text-sakanect-green text-2xl mr-2" />
                <span className="text-2xl font-bold text-sakanect-green">SakaNect</span>
              </div>
              <p className="text-gray-400 mb-4">
                Connecting farmers and buyers across the Philippines for sustainable agriculture and fair trade.
              </p>
            </div>

            <div>
              <h3 className="text-lg font-semibold mb-4">For Farmers</h3>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#" className="hover:text-white">List Your Crops</a></li>
                <li><a href="#" className="hover:text-white">Farmer Resources</a></li>
                <li><a href="#" className="hover:text-white">Success Stories</a></li>
              </ul>
            </div>

            <div>
              <h3 className="text-lg font-semibold mb-4">For Buyers</h3>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#" className="hover:text-white">Browse Crops</a></li>
                <li><a href="#" className="hover:text-white">Quality Guarantee</a></li>
                <li><a href="#" className="hover:text-white">Bulk Orders</a></li>
              </ul>
            </div>

            <div>
              <h3 className="text-lg font-semibold mb-4">Company</h3>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#" className="hover:text-white">About Us</a></li>
                <li><a href="#" className="hover:text-white">Contact</a></li>
                <li><a href="#" className="hover:text-white">Privacy Policy</a></li>
              </ul>
            </div>
          </div>

          <div className="border-t border-gray-800 mt-8 pt-8 text-center">
            <p className="text-gray-400">&copy; 2024 SakaNect. All rights reserved. Connecting Philippine agriculture.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
