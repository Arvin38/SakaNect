import { useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import Navigation from "@/components/navigation";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  LineChart,
  Line,
  Area,
  AreaChart
} from "recharts";
import { 
  TrendingUp, 
  TrendingDown, 
  DollarSign, 
  Users, 
  Package,
  Calendar,
  ArrowUp,
  ArrowDown
} from "lucide-react";

const COLORS = ['#2ECC71', '#3498DB', '#9B59B6', '#E74C3C', '#F39C12'];

export default function Insights() {
  const { user, isAuthenticated, isLoading: authLoading } = useAuth();
  const { toast } = useToast();

  // Redirect if not authenticated
  useEffect(() => {
    if (!authLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, authLoading, toast]);

  const { data: stats } = useQuery({
    queryKey: ["/api/dashboard/stats"],
    retry: false,
  });

  const { data: crops } = useQuery({
    queryKey: ["/api/crops", { farmerId: user?.id }],
    retry: false,
    enabled: user?.role === 'farmer',
  });

  const { data: allRequests } = useQuery({
    queryKey: ["/api/crop-requests"],
    retry: false,
  });

  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-sakanect-green"></div>
      </div>
    );
  }

  if (!user) return null;

  const isFarmer = user.role === 'farmer';

  // Process data for charts
  const processTransactionData = () => {
    if (!allRequests) return [];
    
    const monthlyData: Record<string, any> = {};
    
    allRequests.forEach((request: any) => {
      if (request.status === 'completed') {
        const date = new Date(request.createdAt);
        const monthKey = date.toLocaleDateString('en-US', { month: 'short', year: 'numeric' });
        
        if (!monthlyData[monthKey]) {
          monthlyData[monthKey] = {
            month: monthKey,
            sales: 0,
            barters: 0,
            donations: 0,
            revenue: 0,
          };
        }
        
        monthlyData[monthKey][request.transactionType + 's']++;
        
        if (request.transactionType === 'sale' && request.offeredPrice) {
          monthlyData[monthKey].revenue += parseFloat(request.offeredPrice) * request.requestedQuantity;
        }
      }
    });
    
    return Object.values(monthlyData).slice(-6); // Last 6 months
  };

  const processCropCategoryData = () => {
    if (!crops) return [];
    
    const categoryData: Record<string, number> = {};
    
    crops.forEach((crop: any) => {
      categoryData[crop.category] = (categoryData[crop.category] || 0) + 1;
    });
    
    return Object.entries(categoryData).map(([category, count]) => ({
      name: category.charAt(0).toUpperCase() + category.slice(1),
      value: count,
    }));
  };

  const processPerformanceData = () => {
    if (!allRequests) return [];
    
    const last30Days = Array.from({length: 30}, (_, i) => {
      const date = new Date();
      date.setDate(date.getDate() - (29 - i));
      return {
        date: date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
        requests: 0,
        completed: 0,
      };
    });
    
    allRequests.forEach((request: any) => {
      const requestDate = new Date(request.createdAt);
      const today = new Date();
      const diffTime = Math.abs(today.getTime() - requestDate.getTime());
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      
      if (diffDays <= 30) {
        const dayIndex = 30 - diffDays;
        if (dayIndex >= 0 && dayIndex < 30) {
          last30Days[dayIndex].requests++;
          if (request.status === 'completed') {
            last30Days[dayIndex].completed++;
          }
        }
      }
    });
    
    return last30Days;
  };

  const transactionData = processTransactionData();
  const categoryData = processCropCategoryData();
  const performanceData = processPerformanceData();
  
  // Calculate growth metrics
  const currentMonthRequests = allRequests?.filter((r: any) => {
    const date = new Date(r.createdAt);
    const now = new Date();
    return date.getMonth() === now.getMonth() && date.getFullYear() === now.getFullYear();
  }).length || 0;
  
  const lastMonthRequests = allRequests?.filter((r: any) => {
    const date = new Date(r.createdAt);
    const now = new Date();
    const lastMonth = new Date(now.getFullYear(), now.getMonth() - 1, 1);
    return date.getMonth() === lastMonth.getMonth() && date.getFullYear() === lastMonth.getFullYear();
  }).length || 0;
  
  const requestGrowth = lastMonthRequests > 0 
    ? ((currentMonthRequests - lastMonthRequests) / lastMonthRequests * 100).toFixed(1)
    : '0';

  return (
    <div className="min-h-screen bg-gray-50">
      <Navigation />
      
      <div className="lg:ml-64">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {/* Page Header */}
          <Card className="mb-8">
            <CardHeader>
              <CardTitle className="text-2xl font-bold text-gray-900">
                Analytics & Insights
              </CardTitle>
              <p className="text-gray-600">
                {isFarmer 
                  ? "Track your farm performance and sales analytics"
                  : "Monitor your purchasing patterns and market insights"
                }
              </p>
            </CardHeader>
          </Card>

          {/* Key Metrics */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">This Month</p>
                    <p className="text-2xl font-bold text-gray-900">{currentMonthRequests}</p>
                  </div>
                  <div className="flex items-center space-x-1">
                    {parseFloat(requestGrowth) >= 0 ? (
                      <ArrowUp className="w-4 h-4 text-green-500" />
                    ) : (
                      <ArrowDown className="w-4 h-4 text-red-500" />
                    )}
                    <span className={`text-sm font-medium ${
                      parseFloat(requestGrowth) >= 0 ? 'text-green-500' : 'text-red-500'
                    }`}>
                      {requestGrowth}%
                    </span>
                  </div>
                </div>
                <div className="mt-2">
                  <Badge variant="outline" className="text-xs">
                    vs last month
                  </Badge>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center">
                  <div className="flex-shrink-0">
                    <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                      <Users className="text-blue-600 text-xl" />
                    </div>
                  </div>
                  <div className="ml-4">
                    <p className="text-sm font-medium text-gray-600">Active Users</p>
                    <p className="text-2xl font-bold text-gray-900">
                      {new Set(allRequests?.map((r: any) => isFarmer ? r.buyerId : r.farmerId)).size || 0}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center">
                  <div className="flex-shrink-0">
                    <div className="w-12 h-12 bg-sakanect-green bg-opacity-20 rounded-lg flex items-center justify-center">
                      <Package className="text-sakanect-green text-xl" />
                    </div>
                  </div>
                  <div className="ml-4">
                    <p className="text-sm font-medium text-gray-600">
                      {isFarmer ? 'Total Crops' : 'Completed Orders'}
                    </p>
                    <p className="text-2xl font-bold text-gray-900">
                      {isFarmer 
                        ? crops?.length || 0
                        : allRequests?.filter((r: any) => r.status === 'completed').length || 0
                      }
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center">
                  <div className="flex-shrink-0">
                    <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                      <DollarSign className="text-green-600 text-xl" />
                    </div>
                  </div>
                  <div className="ml-4">
                    <p className="text-sm font-medium text-gray-600">Success Rate</p>
                    <p className="text-2xl font-bold text-gray-900">
                      {allRequests && allRequests.length > 0 
                        ? Math.round((allRequests.filter((r: any) => r.status === 'completed').length / allRequests.length) * 100)
                        : 0
                      }%
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Charts Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
            {/* Monthly Transaction Trends */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <TrendingUp className="w-5 h-5 mr-2 text-sakanect-green" />
                  Monthly Transaction Trends
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={transactionData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis 
                        dataKey="month" 
                        tick={{ fontSize: 12 }}
                      />
                      <YAxis tick={{ fontSize: 12 }} />
                      <Tooltip />
                      <Area 
                        type="monotone" 
                        dataKey="revenue" 
                        stroke="#2ECC71" 
                        fill="#2ECC71" 
                        fillOpacity={0.3}
                        name="Revenue (₱)"
                      />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            {/* Transaction Types Distribution */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Package className="w-5 h-5 mr-2 text-blue-600" />
                  Transaction Types
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  {transactionData.length > 0 ? (
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={transactionData}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="month" tick={{ fontSize: 12 }} />
                        <YAxis tick={{ fontSize: 12 }} />
                        <Tooltip />
                        <Bar dataKey="sales" fill="#2ECC71" name="Sales" />
                        <Bar dataKey="barters" fill="#3498DB" name="Barters" />
                        <Bar dataKey="donations" fill="#9B59B6" name="Donations" />
                      </BarChart>
                    </ResponsiveContainer>
                  ) : (
                    <div className="flex items-center justify-center h-full">
                      <div className="text-center">
                        <Package className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                        <p className="text-gray-500">No transaction data available</p>
                      </div>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Additional Charts */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Crop Categories (for farmers) */}
            {isFarmer && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Package className="w-5 h-5 mr-2 text-green-600" />
                    Crop Categories
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-80">
                    {categoryData.length > 0 ? (
                      <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                          <Pie
                            data={categoryData}
                            cx="50%"
                            cy="50%"
                            labelLine={false}
                            label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                            outerRadius={80}
                            fill="#8884d8"
                            dataKey="value"
                          >
                            {categoryData.map((entry, index) => (
                              <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                            ))}
                          </Pie>
                          <Tooltip />
                        </PieChart>
                      </ResponsiveContainer>
                    ) : (
                      <div className="flex items-center justify-center h-full">
                        <div className="text-center">
                          <Package className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                          <p className="text-gray-500">No crop data available</p>
                        </div>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            )}

            {/* 30-Day Performance */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Calendar className="w-5 h-5 mr-2 text-purple-600" />
                  30-Day Activity
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={performanceData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis 
                        dataKey="date" 
                        tick={{ fontSize: 10 }}
                        interval="preserveStartEnd"
                      />
                      <YAxis tick={{ fontSize: 12 }} />
                      <Tooltip />
                      <Line 
                        type="monotone" 
                        dataKey="requests" 
                        stroke="#3498DB" 
                        strokeWidth={2}
                        name="Requests"
                      />
                      <Line 
                        type="monotone" 
                        dataKey="completed" 
                        stroke="#2ECC71" 
                        strokeWidth={2}
                        name="Completed"
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
