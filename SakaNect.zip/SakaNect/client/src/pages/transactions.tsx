import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import Navigation from "@/components/navigation";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { 
  ArrowRightLeft, 
  DollarSign, 
  Heart, 
  Filter,
  Download,
  Eye,
  MessageCircle,
  Calendar
} from "lucide-react";
import { cn } from "@/lib/utils";

export default function Transactions() {
  const { user, isAuthenticated, isLoading: authLoading } = useAuth();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("all");
  const [statusFilter, setStatusFilter] = useState("");
  const [dateFilter, setDateFilter] = useState("");

  // Redirect if not authenticated
  useEffect(() => {
    if (!authLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, authLoading, toast]);

  const { data: transactions, isLoading } = useQuery({
    queryKey: ["/api/crop-requests", { status: "completed" }],
    retry: false,
  });

  const { data: allRequests, isLoading: allRequestsLoading } = useQuery({
    queryKey: ["/api/crop-requests"],
    retry: false,
  });

  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-sakanect-green"></div>
      </div>
    );
  }

  if (!user) return null;

  const isFarmer = user.role === 'farmer';

  // Filter transactions based on active tab and filters
  const filteredTransactions = allRequests?.filter((request: any) => {
    // Tab filter
    if (activeTab === "sales" && request.transactionType !== "sale") return false;
    if (activeTab === "barters" && request.transactionType !== "barter") return false;
    if (activeTab === "donations" && request.transactionType !== "donation") return false;
    
    // Status filter
    if (statusFilter && request.status !== statusFilter) return false;
    
    return true;
  }) || [];

  // Calculate summary stats
  const completedTransactions = allRequests?.filter((r: any) => r.status === "completed") || [];
  const totalSales = completedTransactions
    .filter((r: any) => r.transactionType === "sale")
    .reduce((sum: number, r: any) => sum + (parseFloat(r.offeredPrice || "0") * r.requestedQuantity), 0);
  
  const totalBarters = completedTransactions.filter((r: any) => r.transactionType === "barter").length;
  const totalDonations = completedTransactions.filter((r: any) => r.transactionType === "donation").length;

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'pending':
        return <Badge className="bg-yellow-500 text-white">Pending</Badge>;
      case 'approved':
        return <Badge className="bg-sakanect-green text-white">Approved</Badge>;
      case 'completed':
        return <Badge className="bg-blue-500 text-white">Completed</Badge>;
      case 'declined':
        return <Badge className="bg-red-500 text-white">Declined</Badge>;
      case 'cancelled':
        return <Badge variant="secondary">Cancelled</Badge>;
      default:
        return <Badge variant="secondary">{status}</Badge>;
    }
  };

  const getTransactionIcon = (type: string) => {
    switch (type) {
      case 'sale':
        return <DollarSign className="w-4 h-4 text-green-600" />;
      case 'barter':
        return <ArrowRightLeft className="w-4 h-4 text-blue-600" />;
      case 'donation':
        return <Heart className="w-4 h-4 text-purple-600" />;
      default:
        return <DollarSign className="w-4 h-4" />;
    }
  };

  const getTransactionTypeColor = (type: string) => {
    switch (type) {
      case 'sale':
        return 'bg-green-100 text-green-800';
      case 'barter':
        return 'bg-blue-100 text-blue-800';
      case 'donation':
        return 'bg-purple-100 text-purple-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Navigation />
      
      <div className="lg:ml-64">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {/* Page Header */}
          <Card className="mb-8">
            <CardHeader>
              <CardTitle className="text-2xl font-bold text-gray-900">
                Transaction Management
              </CardTitle>
              <p className="text-gray-600">
                Track your sales, purchases, and trade history
              </p>
            </CardHeader>
          </Card>

          {/* Summary Stats */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center">
                  <div className="flex-shrink-0">
                    <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                      <DollarSign className="text-green-600 text-xl" />
                    </div>
                  </div>
                  <div className="ml-4">
                    <p className="text-sm font-medium text-gray-600">Total Sales</p>
                    <p className="text-2xl font-bold text-gray-900">₱{totalSales.toLocaleString()}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center">
                  <div className="flex-shrink-0">
                    <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                      <ArrowRightLeft className="text-blue-600 text-xl" />
                    </div>
                  </div>
                  <div className="ml-4">
                    <p className="text-sm font-medium text-gray-600">Barter Trades</p>
                    <p className="text-2xl font-bold text-gray-900">{totalBarters}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center">
                  <div className="flex-shrink-0">
                    <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                      <Heart className="text-purple-600 text-xl" />
                    </div>
                  </div>
                  <div className="ml-4">
                    <p className="text-sm font-medium text-gray-600">Donations</p>
                    <p className="text-2xl font-bold text-gray-900">{totalDonations}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center">
                  <div className="flex-shrink-0">
                    <div className="w-12 h-12 bg-gray-100 rounded-lg flex items-center justify-center">
                      <Calendar className="text-gray-600 text-xl" />
                    </div>
                  </div>
                  <div className="ml-4">
                    <p className="text-sm font-medium text-gray-600">This Month</p>
                    <p className="text-2xl font-bold text-gray-900">
                      {filteredTransactions.filter((t: any) => {
                        const transactionDate = new Date(t.createdAt);
                        const currentDate = new Date();
                        return transactionDate.getMonth() === currentDate.getMonth() &&
                               transactionDate.getFullYear() === currentDate.getFullYear();
                      }).length}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Filters */}
          <Card className="mb-8">
            <CardContent className="p-6">
              <div className="flex flex-wrap items-center gap-4">
                <div className="flex items-center space-x-2">
                  <Filter className="w-4 h-4 text-gray-500" />
                  <span className="text-sm font-medium text-gray-700">Filters:</span>
                </div>
                
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger className="w-40">
                    <SelectValue placeholder="All Status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="">All Status</SelectItem>
                    <SelectItem value="pending">Pending</SelectItem>
                    <SelectItem value="approved">Approved</SelectItem>
                    <SelectItem value="completed">Completed</SelectItem>
                    <SelectItem value="declined">Declined</SelectItem>
                  </SelectContent>
                </Select>

                <Input
                  type="date"
                  value={dateFilter}
                  onChange={(e) => setDateFilter(e.target.value)}
                  className="w-40"
                />

                <Button variant="outline" size="sm">
                  <Download className="w-4 h-4 mr-2" />
                  Export
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Transaction Tabs */}
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="all">All</TabsTrigger>
              <TabsTrigger value="sales">Sales</TabsTrigger>
              <TabsTrigger value="barters">Barters</TabsTrigger>
              <TabsTrigger value="donations">Donations</TabsTrigger>
            </TabsList>

            <TabsContent value={activeTab} className="mt-6">
              <Card>
                <CardContent className="p-0">
                  {isLoading || allRequestsLoading ? (
                    <div className="p-6">
                      <div className="space-y-4">
                        {[...Array(5)].map((_, i) => (
                          <div key={i} className="flex items-center space-x-4 p-4 border rounded-lg">
                            <Skeleton className="h-12 w-12 rounded-lg" />
                            <div className="flex-1">
                              <Skeleton className="h-4 w-32 mb-2" />
                              <Skeleton className="h-3 w-48" />
                            </div>
                            <Skeleton className="h-6 w-20" />
                            <Skeleton className="h-8 w-16" />
                          </div>
                        ))}
                      </div>
                    </div>
                  ) : filteredTransactions.length > 0 ? (
                    <div className="overflow-x-auto">
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>Transaction</TableHead>
                            <TableHead>Party</TableHead>
                            <TableHead>Type</TableHead>
                            <TableHead>Amount</TableHead>
                            <TableHead>Status</TableHead>
                            <TableHead>Date</TableHead>
                            <TableHead>Actions</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {filteredTransactions.map((transaction: any) => (
                            <TableRow key={transaction.id}>
                              <TableCell>
                                <div className="flex items-center space-x-3">
                                  {transaction.crop?.imageUrl && (
                                    <img 
                                      className="h-12 w-12 rounded-lg object-cover" 
                                      src={transaction.crop.imageUrl} 
                                      alt={transaction.crop.name}
                                      onError={(e) => {
                                        const target = e.target as HTMLImageElement;
                                        target.style.display = 'none';
                                      }}
                                    />
                                  )}
                                  <div>
                                    <div className="font-medium text-gray-900">
                                      {transaction.crop?.name}
                                    </div>
                                    <div className="text-sm text-gray-500">
                                      {transaction.requestedQuantity} {transaction.crop?.unit}
                                    </div>
                                  </div>
                                </div>
                              </TableCell>
                              
                              <TableCell>
                                <div className="flex items-center space-x-2">
                                  <Avatar className="h-8 w-8">
                                    <AvatarImage 
                                      src={isFarmer ? transaction.buyer?.profileImageUrl : transaction.farmer?.profileImageUrl} 
                                      alt="User" 
                                    />
                                    <AvatarFallback>
                                      {isFarmer 
                                        ? transaction.buyer?.firstName?.[0]?.toUpperCase() 
                                        : transaction.farmer?.firstName?.[0]?.toUpperCase()
                                      }
                                    </AvatarFallback>
                                  </Avatar>
                                  <div>
                                    <div className="font-medium text-gray-900">
                                      {isFarmer 
                                        ? `${transaction.buyer?.firstName} ${transaction.buyer?.lastName || ''}`.trim()
                                        : `${transaction.farmer?.firstName} ${transaction.farmer?.lastName || ''}`.trim()
                                      }
                                    </div>
                                    <div className="text-sm text-gray-500">
                                      {isFarmer ? 'Buyer' : 'Farmer'}
                                    </div>
                                  </div>
                                </div>
                              </TableCell>
                              
                              <TableCell>
                                <Badge className={cn("flex items-center w-fit", getTransactionTypeColor(transaction.transactionType))}>
                                  {getTransactionIcon(transaction.transactionType)}
                                  <span className="ml-1 capitalize">{transaction.transactionType}</span>
                                </Badge>
                              </TableCell>
                              
                              <TableCell>
                                {transaction.transactionType === 'sale' ? (
                                  <span className="font-medium">
                                    ₱{(parseFloat(transaction.offeredPrice || "0") * transaction.requestedQuantity).toFixed(2)}
                                  </span>
                                ) : transaction.transactionType === 'barter' ? (
                                  <span className="text-sm">{transaction.barterOffer || 'Barter Trade'}</span>
                                ) : (
                                  <span className="text-sm text-purple-600">Free</span>
                                )}
                              </TableCell>
                              
                              <TableCell>
                                {getStatusBadge(transaction.status)}
                              </TableCell>
                              
                              <TableCell>
                                <span className="text-sm text-gray-500">
                                  {new Date(transaction.createdAt).toLocaleDateString()}
                                </span>
                              </TableCell>
                              
                              <TableCell>
                                <div className="flex items-center space-x-2">
                                  <Button variant="ghost" size="sm" className="text-sakanect-green">
                                    <Eye className="w-4 h-4" />
                                  </Button>
                                  <Button variant="ghost" size="sm" className="text-blue-600">
                                    <MessageCircle className="w-4 h-4" />
                                  </Button>
                                </div>
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </div>
                  ) : (
                    <div className="p-12 text-center">
                      <ArrowRightLeft className="text-gray-400 text-6xl mx-auto mb-4" />
                      <h3 className="text-xl font-semibold text-gray-900 mb-2">No transactions found</h3>
                      <p className="text-gray-600">
                        {activeTab === 'all' 
                          ? "Your transactions will appear here once you start trading"
                          : `No ${activeTab} transactions found`
                        }
                      </p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}
