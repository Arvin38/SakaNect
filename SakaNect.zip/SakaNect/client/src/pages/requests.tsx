import { useEffect, useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest } from "@/lib/queryClient";
import Navigation from "@/components/navigation";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  MapPin, 
  User, 
  Phone, 
  MessageCircle, 
  Check, 
  X, 
  Clock,
  DollarSign,
  ArrowRightLeft
} from "lucide-react";
import { cn } from "@/lib/utils";

export default function Requests() {
  const { user, isAuthenticated, isLoading: authLoading } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState("all");

  // Redirect if not authenticated
  useEffect(() => {
    if (!authLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, authLoading, toast]);

  const { data: requests, isLoading } = useQuery({
    queryKey: ["/api/crop-requests"],
    retry: false,
  });

  const updateRequestMutation = useMutation({
    mutationFn: async ({ id, status }: { id: number; status: string }) => {
      await apiRequest("PATCH", `/api/crop-requests/${id}`, { status });
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Request updated successfully!",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/crop-requests"] });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to update request",
        variant: "destructive",
      });
    },
  });

  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-sakanect-green"></div>
      </div>
    );
  }

  if (!user) return null;

  const isFarmer = user.role === 'farmer';
  
  const filteredRequests = requests?.filter((request: any) => {
    if (activeTab === "all") return true;
    return request.status === activeTab;
  }) || [];

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'pending':
        return <Badge className="bg-yellow-500 text-white"><Clock className="w-3 h-3 mr-1" />Pending</Badge>;
      case 'approved':
        return <Badge className="bg-sakanect-green text-white"><Check className="w-3 h-3 mr-1" />Approved</Badge>;
      case 'completed':
        return <Badge className="bg-blue-500 text-white"><Check className="w-3 h-3 mr-1" />Completed</Badge>;
      case 'declined':
        return <Badge className="bg-red-500 text-white"><X className="w-3 h-3 mr-1" />Declined</Badge>;
      case 'cancelled':
        return <Badge variant="secondary"><X className="w-3 h-3 mr-1" />Cancelled</Badge>;
      default:
        return <Badge variant="secondary">{status}</Badge>;
    }
  };

  const getTransactionIcon = (type: string) => {
    switch (type) {
      case 'sale':
        return <DollarSign className="w-4 h-4 text-green-600" />;
      case 'barter':
        return <ArrowRightLeft className="w-4 h-4 text-blue-600" />;
      case 'donation':
        return <User className="w-4 h-4 text-purple-600" />;
      default:
        return <DollarSign className="w-4 h-4" />;
    }
  };

  const handleApprove = (requestId: number) => {
    updateRequestMutation.mutate({ id: requestId, status: 'approved' });
  };

  const handleDecline = (requestId: number) => {
    updateRequestMutation.mutate({ id: requestId, status: 'declined' });
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Navigation />
      
      <div className="lg:ml-64">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <Card className="mb-8">
            <CardHeader>
              <CardTitle className="text-2xl font-bold text-gray-900">
                {isFarmer ? "Crop Requests" : "My Requests"}
              </CardTitle>
              <p className="text-gray-600">
                {isFarmer 
                  ? "Manage incoming requests for your crops" 
                  : "Track your crop purchase requests"}
              </p>
            </CardHeader>
          </Card>

          {/* Status Filter Tabs */}
          <Tabs value={activeTab} onValueChange={setActiveTab} className="mb-6">
            <TabsList className="grid w-full grid-cols-5">
              <TabsTrigger value="all">All</TabsTrigger>
              <TabsTrigger value="pending">Pending</TabsTrigger>
              <TabsTrigger value="approved">Approved</TabsTrigger>
              <TabsTrigger value="completed">Completed</TabsTrigger>
              <TabsTrigger value="declined">Declined</TabsTrigger>
            </TabsList>

            <TabsContent value={activeTab} className="mt-6">
              {isLoading ? (
                <div className="space-y-4">
                  {[...Array(5)].map((_, i) => (
                    <Card key={i}>
                      <CardContent className="p-6">
                        <div className="flex items-center space-x-4">
                          <Skeleton className="h-16 w-16 rounded-lg" />
                          <div className="flex-1">
                            <Skeleton className="h-5 w-32 mb-2" />
                            <Skeleton className="h-4 w-48 mb-2" />
                            <Skeleton className="h-4 w-36" />
                          </div>
                          <div className="flex space-x-2">
                            <Skeleton className="h-8 w-20" />
                            <Skeleton className="h-8 w-20" />
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              ) : filteredRequests.length > 0 ? (
                <div className="space-y-4">
                  {filteredRequests.map((request: any) => (
                    <Card key={request.id} className="hover:shadow-md transition-shadow">
                      <CardContent className="p-6">
                        <div className="flex flex-col lg:flex-row lg:items-center space-y-4 lg:space-y-0 lg:space-x-6">
                          {/* Crop Image and Basic Info */}
                          <div className="flex items-center space-x-4">
                            {request.crop?.imageUrl && (
                              <img 
                                className="h-16 w-16 rounded-lg object-cover" 
                                src={request.crop.imageUrl} 
                                alt={request.crop.name}
                                onError={(e) => {
                                  const target = e.target as HTMLImageElement;
                                  target.style.display = 'none';
                                }}
                              />
                            )}
                            <div>
                              <h3 className="font-semibold text-gray-900 flex items-center">
                                {getTransactionIcon(request.transactionType)}
                                <span className="ml-2">{request.crop?.name}</span>
                              </h3>
                              <p className="text-sm text-gray-600">
                                {request.transactionType === 'sale' ? (
                                  <>₱{request.offeredPrice} per {request.crop?.unit}</>
                                ) : request.transactionType === 'barter' ? (
                                  <>Trade for: {request.barterOffer}</>
                                ) : (
                                  <>Free Donation</>
                                )}
                                <span className="ml-2">• {request.requestedQuantity} {request.crop?.unit}</span>
                              </p>
                              <p className="text-xs text-gray-500 flex items-center mt-1">
                                <MapPin className="w-3 h-3 mr-1" />
                                {request.crop?.location}
                              </p>
                            </div>
                          </div>

                          {/* User Info */}
                          <div className="flex items-center space-x-3">
                            <Avatar className="h-10 w-10">
                              <AvatarImage 
                                src={isFarmer ? request.buyer?.profileImageUrl : request.farmer?.profileImageUrl} 
                                alt="User" 
                              />
                              <AvatarFallback>
                                {isFarmer 
                                  ? request.buyer?.firstName?.[0]?.toUpperCase() 
                                  : request.farmer?.firstName?.[0]?.toUpperCase()
                                }
                              </AvatarFallback>
                            </Avatar>
                            <div>
                              <p className="font-medium text-gray-900">
                                {isFarmer 
                                  ? `${request.buyer?.firstName} ${request.buyer?.lastName || ''}`.trim()
                                  : `${request.farmer?.firstName} ${request.farmer?.lastName || ''}`.trim()
                                }
                              </p>
                              <p className="text-sm text-gray-500">
                                {isFarmer ? 'Buyer' : 'Farmer'}
                              </p>
                            </div>
                          </div>

                          {/* Contact Info */}
                          {request.contactNumber && (
                            <div className="flex items-center text-sm text-gray-600">
                              <Phone className="w-4 h-4 mr-1" />
                              {request.contactNumber}
                            </div>
                          )}

                          {/* Status and Actions */}
                          <div className="flex items-center justify-between lg:justify-end space-x-4 lg:ml-auto">
                            {getStatusBadge(request.status)}
                            
                            <div className="flex space-x-2">
                              {/* Message Button */}
                              <Button
                                variant="outline"
                                size="sm"
                                className="text-blue-600 border-blue-600 hover:bg-blue-50"
                              >
                                <MessageCircle className="w-4 h-4 mr-1" />
                                Message
                              </Button>

                              {/* Action Buttons for Farmers */}
                              {isFarmer && request.status === 'pending' && (
                                <>
                                  <Button
                                    onClick={() => handleApprove(request.id)}
                                    disabled={updateRequestMutation.isPending}
                                    className="bg-sakanect-green text-white hover:bg-sakanect-dark"
                                    size="sm"
                                  >
                                    <Check className="w-4 h-4 mr-1" />
                                    Approve
                                  </Button>
                                  <Button
                                    onClick={() => handleDecline(request.id)}
                                    disabled={updateRequestMutation.isPending}
                                    variant="destructive"
                                    size="sm"
                                  >
                                    <X className="w-4 h-4 mr-1" />
                                    Decline
                                  </Button>
                                </>
                              )}

                              {/* Complete Button for Approved Requests */}
                              {request.status === 'approved' && (
                                <Button
                                  onClick={() => updateRequestMutation.mutate({ 
                                    id: request.id, 
                                    status: 'completed' 
                                  })}
                                  disabled={updateRequestMutation.isPending}
                                  className="bg-blue-600 text-white hover:bg-blue-700"
                                  size="sm"
                                >
                                  <Check className="w-4 h-4 mr-1" />
                                  Complete
                                </Button>
                              )}
                            </div>
                          </div>
                        </div>

                        {/* Additional Notes */}
                        {request.notes && (
                          <div className="mt-4 p-3 bg-gray-50 rounded-lg">
                            <p className="text-sm text-gray-700">
                              <span className="font-medium">Notes:</span> {request.notes}
                            </p>
                          </div>
                        )}

                        {/* Transaction Total */}
                        {request.transactionType === 'sale' && request.offeredPrice && (
                          <div className="mt-4 flex justify-end">
                            <div className="bg-sakanect-green bg-opacity-10 px-4 py-2 rounded-lg">
                              <p className="text-sakanect-dark font-semibold">
                                Total: ₱{(parseFloat(request.offeredPrice) * request.requestedQuantity).toFixed(2)}
                              </p>
                            </div>
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  ))}
                </div>
              ) : (
                <Card>
                  <CardContent className="p-12 text-center">
                    <div className="mb-4">
                      <Clock className="text-gray-400 text-6xl mx-auto mb-4" />
                      <h3 className="text-xl font-semibold text-gray-900 mb-2">
                        No {activeTab === 'all' ? '' : activeTab} requests found
                      </h3>
                      <p className="text-gray-600">
                        {isFarmer 
                          ? "When buyers request your crops, they will appear here"
                          : "Your crop requests will appear here"}
                      </p>
                    </div>
                  </CardContent>
                </Card>
              )}
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}
