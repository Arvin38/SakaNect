import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";

const requestFormSchema = z.object({
  requestedQuantity: z.coerce.number().min(1, "Quantity must be at least 1"),
  offeredPrice: z.string().optional(),
  barterOffer: z.string().optional(),
  contactNumber: z.string().min(1, "Contact number is required"),
  notes: z.string().optional(),
});

type RequestFormData = z.infer<typeof requestFormSchema>;

interface RequestModalProps {
  isOpen: boolean;
  onClose: () => void;
  crop: {
    id: number;
    name: string;
    price: string;
    unit: string;
    quantity: number;
    transactionType: "sale" | "barter" | "donation";
    barterFor?: string;
  };
}

export default function RequestModal({ isOpen, onClose, crop }: RequestModalProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const form = useForm<RequestFormData>({
    resolver: zodResolver(requestFormSchema),
    defaultValues: {
      requestedQuantity: 1,
      offeredPrice: crop.transactionType === 'sale' ? crop.price : '',
      barterOffer: '',
      contactNumber: '',
      notes: '',
    },
  });

  const createRequestMutation = useMutation({
    mutationFn: async (data: RequestFormData) => {
      await apiRequest("POST", "/api/crop-requests", {
        cropId: crop.id,
        transactionType: crop.transactionType,
        ...data,
      });
    },
    onSuccess: () => {
      toast({
        title: "Request Sent",
        description: "Your crop request has been sent to the farmer!",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/crop-requests"] });
      form.reset();
      onClose();
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to send request",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: RequestFormData) => {
    createRequestMutation.mutate(data);
  };

  const maxQuantity = crop.quantity;
  const requestedQuantity = form.watch("requestedQuantity");

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle>
            {crop.transactionType === 'sale' ? 'Request Crop' :
             crop.transactionType === 'barter' ? 'Barter Request' : 'Claim Donation'}
          </DialogTitle>
        </DialogHeader>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <div className="bg-gray-50 p-4 rounded-lg">
              <h4 className="font-medium text-gray-900 mb-2">{crop.name}</h4>
              <div className="text-sm text-gray-600">
                {crop.transactionType === 'sale' ? (
                  <p>Price: ₱{crop.price} per {crop.unit}</p>
                ) : crop.transactionType === 'barter' ? (
                  <p>Looking for: {crop.barterFor}</p>
                ) : (
                  <p>Free donation</p>
                )}
                <p>Available: {crop.quantity} {crop.unit}</p>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="requestedQuantity"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Quantity ({crop.unit}) *</FormLabel>
                    <FormControl>
                      <Input 
                        type="number" 
                        min="1" 
                        max={maxQuantity}
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {crop.transactionType === 'sale' && (
                <FormField
                  control={form.control}
                  name="offeredPrice"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Price per {crop.unit} (₱)</FormLabel>
                      <FormControl>
                        <Input 
                          type="number" 
                          step="0.01"
                          placeholder={crop.price}
                          {...field} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              )}
            </div>

            {crop.transactionType === 'barter' && (
              <FormField
                control={form.control}
                name="barterOffer"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>What do you offer?</FormLabel>
                    <FormControl>
                      <Input 
                        placeholder="e.g., 2kg Rice, 5kg Corn..."
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            )}

            <FormField
              control={form.control}
              name="contactNumber"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Contact Number *</FormLabel>
                  <FormControl>
                    <Input 
                      type="tel"
                      placeholder="+63 XXX XXX XXXX"
                      {...field} 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="notes"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Additional Notes</FormLabel>
                  <FormControl>
                    <Textarea 
                      placeholder="Any special requirements or pickup preferences..."
                      className="resize-none"
                      rows={3}
                      {...field} 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {crop.transactionType === 'sale' && requestedQuantity && (
              <div className="bg-sakanect-green bg-opacity-10 p-3 rounded-lg">
                <p className="text-sm text-sakanect-dark font-medium">
                  Total: ₱{(parseFloat(crop.price) * requestedQuantity).toFixed(2)}
                </p>
              </div>
            )}

            <div className="flex justify-end space-x-2">
              <Button type="button" variant="outline" onClick={onClose}>
                Cancel
              </Button>
              <Button 
                type="submit" 
                className="bg-sakanect-green hover:bg-sakanect-dark"
                disabled={createRequestMutation.isPending}
              >
                {createRequestMutation.isPending ? 'Sending...' : 'Send Request'}
              </Button>
            </div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
