import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { MapPin, User } from "lucide-react";
import { cn } from "@/lib/utils";
import RequestModal from "./request-modal";

interface CropCardProps {
  crop: {
    id: number;
    name: string;
    description: string;
    price: string;
    quantity: number;
    unit: string;
    category: string;
    imageUrl?: string;
    location: string;
    status: string;
    transactionType: "sale" | "barter" | "donation";
    barterFor?: string;
    farmer: {
      id: string;
      firstName: string;
      lastName?: string;
      profileImageUrl?: string;
    };
  };
}

export default function CropCard({ crop }: CropCardProps) {
  const [showRequestModal, setShowRequestModal] = useState(false);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'available':
        return 'bg-sakanect-green text-white';
      case 'limited':
        return 'bg-yellow-500 text-white';
      case 'sold':
        return 'bg-gray-500 text-white';
      default:
        return 'bg-gray-500 text-white';
    }
  };

  const getTransactionTypeColor = (type: string) => {
    switch (type) {
      case 'sale':
        return 'bg-green-100 text-green-800';
      case 'barter':
        return 'bg-blue-100 text-blue-800';
      case 'donation':
        return 'bg-purple-100 text-purple-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getButtonStyle = (type: string) => {
    switch (type) {
      case 'sale':
        return 'bg-sakanect-green hover:bg-sakanect-dark text-white';
      case 'barter':
        return 'bg-blue-500 hover:bg-blue-600 text-white';
      case 'donation':
        return 'bg-purple-500 hover:bg-purple-600 text-white';
      default:
        return 'bg-sakanect-green hover:bg-sakanect-dark text-white';
    }
  };

  const getButtonText = (type: string) => {
    switch (type) {
      case 'sale':
        return 'Request';
      case 'barter':
        return 'Barter';
      case 'donation':
        return 'Claim';
      default:
        return 'Request';
    }
  };

  return (
    <>
      <Card className="overflow-hidden hover:shadow-md transition-shadow">
        {crop.imageUrl && (
          <img 
            className="w-full h-48 object-cover" 
            src={crop.imageUrl} 
            alt={crop.name}
            onError={(e) => {
              const target = e.target as HTMLImageElement;
              target.style.display = 'none';
            }}
          />
        )}
        
        <CardContent className="p-4">
          <div className="flex items-start justify-between mb-2">
            <h3 className="font-semibold text-gray-900 line-clamp-1">{crop.name}</h3>
            <Badge className={getStatusColor(crop.status)}>
              {crop.status}
            </Badge>
          </div>
          
          {crop.description && (
            <p className="text-sm text-gray-600 mb-2 line-clamp-2">{crop.description}</p>
          )}
          
          <div className="flex items-center text-sm text-gray-500 mb-3">
            <User className="w-4 h-4 mr-1" />
            <span>{crop.farmer.firstName} {crop.farmer.lastName}</span>
          </div>
          
          <div className="flex items-center text-sm text-gray-500 mb-3">
            <MapPin className="w-4 h-4 mr-1" />
            <span className="line-clamp-1">{crop.location}</span>
          </div>
          
          <div className="flex items-center justify-between mb-3">
            <div>
              {crop.transactionType === 'sale' ? (
                <span className="text-lg font-bold text-sakanect-green">
                  ₱{crop.price}/{crop.unit}
                </span>
              ) : crop.transactionType === 'barter' ? (
                <span className="text-sm font-medium text-blue-600">
                  Trade for {crop.barterFor || 'Items'}
                </span>
              ) : (
                <span className="text-sm font-medium text-purple-600">
                  Free Donation
                </span>
              )}
              <span className="text-sm text-gray-500 ml-2">
                • {crop.quantity} {crop.unit} available
              </span>
            </div>
          </div>
          
          <div className="flex items-center justify-between">
            <Badge variant="outline" className={getTransactionTypeColor(crop.transactionType)}>
              {crop.transactionType === 'sale' ? 'For Sale' : 
               crop.transactionType === 'barter' ? 'For Barter' : 'For Donation'}
            </Badge>
            
            <Button
              onClick={() => setShowRequestModal(true)}
              className={cn("text-sm font-medium", getButtonStyle(crop.transactionType))}
              size="sm"
              disabled={crop.status === 'sold'}
            >
              {crop.status === 'sold' ? 'Sold Out' : getButtonText(crop.transactionType)}
            </Button>
          </div>
        </CardContent>
      </Card>

      <RequestModal
        isOpen={showRequestModal}
        onClose={() => setShowRequestModal(false)}
        crop={crop}
      />
    </>
  );
}
