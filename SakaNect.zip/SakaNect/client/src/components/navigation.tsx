import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { 
  MapPin, 
  Home, 
  Sprout, 
  Bell, 
  ArrowRightLeft, 
  BarChart3, 
  History,
  Menu,
  Search
} from "lucide-react";
import { useState } from "react";
import { cn } from "@/lib/utils";

export default function Navigation() {
  const { user } = useAuth();
  const [location] = useLocation();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const navigationItems = [
    { href: "/", label: "Dashboard", icon: Home },
    { href: "/browse-crops", label: "Browse Crops", icon: Search },
    { href: "/requests", label: "Requests", icon: Bell, badge: 3 },
    { href: "/transactions", label: "Transactions", icon: ArrowRightLeft },
    { href: "/insights", label: "Insights", icon: BarChart3 },
    { href: "/history", label: "History", icon: History },
  ];

  const isActive = (href: string) => {
    if (href === "/" && location === "/") return true;
    if (href !== "/" && location.startsWith(href)) return true;
    return false;
  };

  return (
    <>
      {/* Desktop Navigation */}
      <nav className="bg-white shadow-sm border-b border-gray-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            {/* Logo */}
            <div className="flex items-center">
              <Link href="/" className="flex items-center">
                <MapPin className="text-sakanect-green text-2xl mr-2" />
                <span className="text-2xl font-bold text-sakanect-green">SakaNect</span>
              </Link>
            </div>

            {/* Desktop Navigation */}
            <div className="hidden md:block">
              <div className="ml-10 flex items-baseline space-x-4">
                {navigationItems.map((item) => (
                  <Link
                    key={item.href}
                    href={item.href}
                    className={cn(
                      "px-3 py-2 rounded-md text-sm font-medium flex items-center space-x-1",
                      isActive(item.href)
                        ? "text-sakanect-green bg-sakanect-green bg-opacity-10"
                        : "text-gray-600 hover:text-sakanect-green hover:bg-gray-50"
                    )}
                  >
                    <item.icon className="w-4 h-4" />
                    <span>{item.label}</span>
                    {item.badge && (
                      <Badge className="ml-1 bg-red-500 text-white">
                        {item.badge}
                      </Badge>
                    )}
                  </Link>
                ))}
              </div>
            </div>

            {/* User Menu */}
            <div className="flex items-center space-x-4">
              <Button variant="ghost" size="sm" className="text-gray-600 hover:text-sakanect-green">
                <Bell className="w-5 h-5" />
              </Button>
              
              <div className="flex items-center space-x-2">
                <Avatar className="h-8 w-8">
                  <AvatarImage 
                    src={user?.profileImageUrl || undefined} 
                    alt={user?.firstName || "User"} 
                  />
                  <AvatarFallback>
                    {user?.firstName?.[0]?.toUpperCase() || user?.email?.[0]?.toUpperCase() || "U"}
                  </AvatarFallback>
                </Avatar>
                <div className="hidden md:block">
                  <span className="font-medium text-gray-700">
                    {user?.firstName || user?.email}
                  </span>
                  <Badge 
                    variant="secondary" 
                    className={cn(
                      "ml-2",
                      user?.role === 'farmer' ? "bg-sakanect-green text-white" : "bg-blue-500 text-white"
                    )}
                  >
                    {user?.role}
                  </Badge>
                </div>
              </div>

              {/* Mobile menu button */}
              <div className="md:hidden">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                  className="text-gray-600 hover:text-sakanect-green"
                >
                  <Menu className="w-5 h-5" />
                </Button>
              </div>

              {/* Logout Button */}
              <Button
                onClick={() => window.location.href = '/api/logout'}
                variant="outline"
                size="sm"
                className="hidden md:flex border-sakanect-green text-sakanect-green hover:bg-sakanect-green hover:text-white"
              >
                Logout
              </Button>
            </div>
          </div>
        </div>

        {/* Mobile Navigation */}
        {isMobileMenuOpen && (
          <div className="md:hidden border-t border-gray-200 bg-white">
            <div className="px-2 pt-2 pb-3 space-y-1">
              {navigationItems.map((item) => (
                <Link
                  key={item.href}
                  href={item.href}
                  onClick={() => setIsMobileMenuOpen(false)}
                  className={cn(
                    "block px-3 py-2 rounded-md text-base font-medium flex items-center space-x-2",
                    isActive(item.href)
                      ? "text-sakanect-green bg-sakanect-green bg-opacity-10"
                      : "text-gray-600 hover:text-sakanect-green hover:bg-gray-50"
                  )}
                >
                  <item.icon className="w-5 h-5" />
                  <span>{item.label}</span>
                  {item.badge && (
                    <Badge className="ml-auto bg-red-500 text-white">
                      {item.badge}
                    </Badge>
                  )}
                </Link>
              ))}
              
              <div className="border-t border-gray-200 pt-2">
                <Button
                  onClick={() => window.location.href = '/api/logout'}
                  variant="outline"
                  className="w-full border-sakanect-green text-sakanect-green hover:bg-sakanect-green hover:text-white"
                >
                  Logout
                </Button>
              </div>
            </div>
          </div>
        )}
      </nav>

      {/* Sidebar for larger screens */}
      <div className="hidden lg:block fixed left-0 top-16 h-full w-64 bg-white shadow-sm border-r border-gray-200">
        <div className="p-6">
          {/* User Profile Card */}
          <div className="bg-gray-50 rounded-lg p-4 mb-6">
            <div className="text-center">
              <Avatar className="h-16 w-16 mx-auto mb-3">
                <AvatarImage 
                  src={user?.profileImageUrl || undefined} 
                  alt={user?.firstName || "User"} 
                />
                <AvatarFallback className="text-lg">
                  {user?.firstName?.[0]?.toUpperCase() || user?.email?.[0]?.toUpperCase() || "U"}
                </AvatarFallback>
              </Avatar>
              <h3 className="font-semibold text-gray-900">
                {user?.firstName && user?.lastName 
                  ? `${user.firstName} ${user.lastName}`
                  : user?.firstName || user?.email}
              </h3>
              <Badge 
                className={cn(
                  "mt-1",
                  user?.role === 'farmer' ? "bg-sakanect-green text-white" : "bg-blue-500 text-white"
                )}
              >
                {user?.role}
              </Badge>
            </div>
          </div>
          
          {/* Navigation Links */}
          <nav className="space-y-2">
            {navigationItems.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className={cn(
                  "flex items-center px-3 py-2 rounded-md font-medium transition-colors",
                  isActive(item.href)
                    ? "text-sakanect-green bg-sakanect-green bg-opacity-20"
                    : "text-gray-600 hover:text-sakanect-green hover:bg-gray-50"
                )}
              >
                <item.icon className="mr-3 w-5 h-5" />
                {item.label}
                {item.badge && (
                  <Badge className="ml-auto bg-red-500 text-white">
                    {item.badge}
                  </Badge>
                )}
              </Link>
            ))}
          </nav>
        </div>
      </div>
    </>
  );
}
