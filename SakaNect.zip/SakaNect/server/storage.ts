import {
  users,
  crops,
  cropRequests,
  messages,
  type User,
  type UpsertUser,
  type Crop,
  type InsertCrop,
  type UpdateCrop,
  type CropRequest,
  type InsertCropRequest,
  type UpdateCropRequest,
  type Message,
  type InsertMessage,
  type CropWithFarmer,
  type CropRequestWithDetails,
  type MessageWithSender,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, or, ilike, count } from "drizzle-orm";

export interface IStorage {
  // User operations (required for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  
  // Crop operations
  getCrops(params?: {
    farmerId?: string;
    category?: string;
    location?: string;
    status?: string;
    search?: string;
    limit?: number;
    offset?: number;
  }): Promise<CropWithFarmer[]>;
  getCrop(id: number): Promise<CropWithFarmer | undefined>;
  createCrop(crop: InsertCrop): Promise<Crop>;
  updateCrop(id: number, crop: UpdateCrop): Promise<Crop>;
  deleteCrop(id: number): Promise<void>;
  
  // Crop request operations
  getCropRequests(params?: {
    farmerId?: string;
    buyerId?: string;
    status?: string;
    limit?: number;
    offset?: number;
  }): Promise<CropRequestWithDetails[]>;
  getCropRequest(id: number): Promise<CropRequestWithDetails | undefined>;
  createCropRequest(request: InsertCropRequest): Promise<CropRequest>;
  updateCropRequest(id: number, request: UpdateCropRequest): Promise<CropRequest>;
  
  // Message operations
  getMessages(params: {
    senderId?: string;
    receiverId?: string;
    requestId?: number;
    limit?: number;
    offset?: number;
  }): Promise<MessageWithSender[]>;
  createMessage(message: InsertMessage): Promise<Message>;
  markMessagesAsRead(receiverId: string, senderId: string): Promise<void>;
  
  // Dashboard stats
  getDashboardStats(userId: string, role: 'farmer' | 'buyer'): Promise<{
    activeCrops?: number;
    pendingRequests: number;
    totalSales?: number;
    totalPurchases?: number;
  }>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // Crop operations
  async getCrops(params?: {
    farmerId?: string;
    category?: string;
    location?: string;
    status?: string;
    search?: string;
    limit?: number;
    offset?: number;
  }): Promise<CropWithFarmer[]> {
    let query = db
      .select()
      .from(crops)
      .innerJoin(users, eq(crops.farmerId, users.id));

    const conditions = [];

    if (params?.farmerId) {
      conditions.push(eq(crops.farmerId, params.farmerId));
    }
    if (params?.category) {
      conditions.push(eq(crops.category, params.category));
    }
    if (params?.location) {
      conditions.push(ilike(crops.location, `%${params.location}%`));
    }
    if (params?.status) {
      conditions.push(eq(crops.status, params.status as any));
    }
    if (params?.search) {
      conditions.push(
        or(
          ilike(crops.name, `%${params.search}%`),
          ilike(crops.description, `%${params.search}%`),
          ilike(users.firstName, `%${params.search}%`),
          ilike(users.lastName, `%${params.search}%`)
        )
      );
    }

    if (conditions.length > 0) {
      query = query.where(and(...conditions));
    }

    query = query.orderBy(desc(crops.createdAt));

    if (params?.limit) {
      query = query.limit(params.limit);
    }
    if (params?.offset) {
      query = query.offset(params.offset);
    }

    const result = await query;
    return result.map(row => ({
      ...row.crops,
      farmer: row.users,
    }));
  }

  async getCrop(id: number): Promise<CropWithFarmer | undefined> {
    const [result] = await db
      .select()
      .from(crops)
      .innerJoin(users, eq(crops.farmerId, users.id))
      .where(eq(crops.id, id));

    if (!result) return undefined;

    return {
      ...result.crops,
      farmer: result.users,
    };
  }

  async createCrop(crop: InsertCrop): Promise<Crop> {
    const [newCrop] = await db.insert(crops).values(crop).returning();
    return newCrop;
  }

  async updateCrop(id: number, crop: UpdateCrop): Promise<Crop> {
    const [updatedCrop] = await db
      .update(crops)
      .set({ ...crop, updatedAt: new Date() })
      .where(eq(crops.id, id))
      .returning();
    return updatedCrop;
  }

  async deleteCrop(id: number): Promise<void> {
    await db.delete(crops).where(eq(crops.id, id));
  }

  // Crop request operations
  async getCropRequests(params?: {
    farmerId?: string;
    buyerId?: string;
    status?: string;
    limit?: number;
    offset?: number;
  }): Promise<CropRequestWithDetails[]> {
    let query = db
      .select()
      .from(cropRequests)
      .innerJoin(crops, eq(cropRequests.cropId, crops.id))
      .innerJoin(users, eq(crops.farmerId, users.id))
      .leftJoin(users, eq(cropRequests.buyerId, users.id));

    const conditions = [];

    if (params?.farmerId) {
      conditions.push(eq(cropRequests.farmerId, params.farmerId));
    }
    if (params?.buyerId) {
      conditions.push(eq(cropRequests.buyerId, params.buyerId));
    }
    if (params?.status) {
      conditions.push(eq(cropRequests.status, params.status as any));
    }

    if (conditions.length > 0) {
      query = query.where(and(...conditions));
    }

    query = query.orderBy(desc(cropRequests.createdAt));

    if (params?.limit) {
      query = query.limit(params.limit);
    }
    if (params?.offset) {
      query = query.offset(params.offset);
    }

    const result = await query;
    return result.map(row => {
      const farmer = row.users;
      const buyer = row.users_1 || row.users; // Handle the join alias
      
      return {
        ...row.crop_requests,
        crop: {
          ...row.crops,
          farmer,
        },
        buyer,
        farmer,
      };
    });
  }

  async getCropRequest(id: number): Promise<CropRequestWithDetails | undefined> {
    const [result] = await db
      .select()
      .from(cropRequests)
      .innerJoin(crops, eq(cropRequests.cropId, crops.id))
      .innerJoin(users, eq(crops.farmerId, users.id))
      .leftJoin(users, eq(cropRequests.buyerId, users.id))
      .where(eq(cropRequests.id, id));

    if (!result) return undefined;

    const farmer = result.users;
    const buyer = result.users_1 || result.users;

    return {
      ...result.crop_requests,
      crop: {
        ...result.crops,
        farmer,
      },
      buyer,
      farmer,
    };
  }

  async createCropRequest(request: InsertCropRequest): Promise<CropRequest> {
    const [newRequest] = await db.insert(cropRequests).values(request).returning();
    return newRequest;
  }

  async updateCropRequest(id: number, request: UpdateCropRequest): Promise<CropRequest> {
    const [updatedRequest] = await db
      .update(cropRequests)
      .set({ ...request, updatedAt: new Date() })
      .where(eq(cropRequests.id, id))
      .returning();
    return updatedRequest;
  }

  // Message operations
  async getMessages(params: {
    senderId?: string;
    receiverId?: string;
    requestId?: number;
    limit?: number;
    offset?: number;
  }): Promise<MessageWithSender[]> {
    let query = db
      .select()
      .from(messages)
      .innerJoin(users, eq(messages.senderId, users.id));

    const conditions = [];

    if (params.senderId) {
      conditions.push(eq(messages.senderId, params.senderId));
    }
    if (params.receiverId) {
      conditions.push(eq(messages.receiverId, params.receiverId));
    }
    if (params.requestId) {
      conditions.push(eq(messages.requestId, params.requestId));
    }

    if (conditions.length > 0) {
      query = query.where(and(...conditions));
    }

    query = query.orderBy(desc(messages.createdAt));

    if (params.limit) {
      query = query.limit(params.limit);
    }
    if (params.offset) {
      query = query.offset(params.offset);
    }

    const result = await query;
    return result.map(row => ({
      ...row.messages,
      sender: row.users,
    }));
  }

  async createMessage(message: InsertMessage): Promise<Message> {
    const [newMessage] = await db.insert(messages).values(message).returning();
    return newMessage;
  }

  async markMessagesAsRead(receiverId: string, senderId: string): Promise<void> {
    await db
      .update(messages)
      .set({ isRead: true })
      .where(
        and(
          eq(messages.receiverId, receiverId),
          eq(messages.senderId, senderId)
        )
      );
  }

  // Dashboard stats
  async getDashboardStats(userId: string, role: 'farmer' | 'buyer'): Promise<{
    activeCrops?: number;
    pendingRequests: number;
    totalSales?: number;
    totalPurchases?: number;
  }> {
    const stats: any = {};

    if (role === 'farmer') {
      // Active crops count
      const [activeCropsResult] = await db
        .select({ count: count() })
        .from(crops)
        .where(
          and(
            eq(crops.farmerId, userId),
            eq(crops.status, 'available')
          )
        );
      stats.activeCrops = activeCropsResult.count;

      // Pending requests count
      const [pendingRequestsResult] = await db
        .select({ count: count() })
        .from(cropRequests)
        .where(
          and(
            eq(cropRequests.farmerId, userId),
            eq(cropRequests.status, 'pending')
          )
        );
      stats.pendingRequests = pendingRequestsResult.count;

      // Total sales (completed transactions)
      const completedSales = await db
        .select()
        .from(cropRequests)
        .where(
          and(
            eq(cropRequests.farmerId, userId),
            eq(cropRequests.status, 'completed'),
            eq(cropRequests.transactionType, 'sale')
          )
        );
      
      stats.totalSales = completedSales.reduce((total, sale) => {
        return total + (parseFloat(sale.offeredPrice || '0') * sale.requestedQuantity);
      }, 0);
    } else {
      // Pending requests count (as buyer)
      const [pendingRequestsResult] = await db
        .select({ count: count() })
        .from(cropRequests)
        .where(
          and(
            eq(cropRequests.buyerId, userId),
            eq(cropRequests.status, 'pending')
          )
        );
      stats.pendingRequests = pendingRequestsResult.count;

      // Total purchases
      const completedPurchases = await db
        .select()
        .from(cropRequests)
        .where(
          and(
            eq(cropRequests.buyerId, userId),
            eq(cropRequests.status, 'completed'),
            eq(cropRequests.transactionType, 'sale')
          )
        );
      
      stats.totalPurchases = completedPurchases.reduce((total, purchase) => {
        return total + (parseFloat(purchase.offeredPrice || '0') * purchase.requestedQuantity);
      }, 0);
    }

    return stats;
  }
}

export const storage = new DatabaseStorage();
