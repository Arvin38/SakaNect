import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { 
  insertCropSchema, 
  updateCropSchema,
  insertCropRequestSchema,
  updateCropRequestSchema,
  insertMessageSchema
} from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Update user profile
  app.patch('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const updateData = req.body;
      
      const user = await storage.upsertUser({
        id: userId,
        ...updateData,
      });
      
      res.json(user);
    } catch (error) {
      console.error("Error updating user:", error);
      res.status(500).json({ message: "Failed to update user" });
    }
  });

  // Crop routes
  app.get('/api/crops', async (req, res) => {
    try {
      const {
        farmerId,
        category,
        location,
        status,
        search,
        limit = '20',
        offset = '0'
      } = req.query;

      const crops = await storage.getCrops({
        farmerId: farmerId as string,
        category: category as string,
        location: location as string,
        status: status as string,
        search: search as string,
        limit: parseInt(limit as string),
        offset: parseInt(offset as string),
      });

      res.json(crops);
    } catch (error) {
      console.error("Error fetching crops:", error);
      res.status(500).json({ message: "Failed to fetch crops" });
    }
  });

  app.get('/api/crops/:id', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const crop = await storage.getCrop(id);
      
      if (!crop) {
        return res.status(404).json({ message: "Crop not found" });
      }
      
      res.json(crop);
    } catch (error) {
      console.error("Error fetching crop:", error);
      res.status(500).json({ message: "Failed to fetch crop" });
    }
  });

  app.post('/api/crops', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const cropData = insertCropSchema.parse({
        ...req.body,
        farmerId: userId,
      });

      const crop = await storage.createCrop(cropData);
      res.json(crop);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid crop data", errors: error.errors });
      }
      console.error("Error creating crop:", error);
      res.status(500).json({ message: "Failed to create crop" });
    }
  });

  app.patch('/api/crops/:id', isAuthenticated, async (req: any, res) => {
    try {
      const id = parseInt(req.params.id);
      const userId = req.user.claims.sub;
      
      // Check if user owns this crop
      const existingCrop = await storage.getCrop(id);
      if (!existingCrop || existingCrop.farmerId !== userId) {
        return res.status(403).json({ message: "Unauthorized to update this crop" });
      }

      const updateData = updateCropSchema.parse(req.body);
      const crop = await storage.updateCrop(id, updateData);
      res.json(crop);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid crop data", errors: error.errors });
      }
      console.error("Error updating crop:", error);
      res.status(500).json({ message: "Failed to update crop" });
    }
  });

  app.delete('/api/crops/:id', isAuthenticated, async (req: any, res) => {
    try {
      const id = parseInt(req.params.id);
      const userId = req.user.claims.sub;
      
      // Check if user owns this crop
      const existingCrop = await storage.getCrop(id);
      if (!existingCrop || existingCrop.farmerId !== userId) {
        return res.status(403).json({ message: "Unauthorized to delete this crop" });
      }

      await storage.deleteCrop(id);
      res.json({ message: "Crop deleted successfully" });
    } catch (error) {
      console.error("Error deleting crop:", error);
      res.status(500).json({ message: "Failed to delete crop" });
    }
  });

  // Crop request routes
  app.get('/api/crop-requests', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      const {
        status,
        limit = '20',
        offset = '0'
      } = req.query;

      const params: any = {
        status: status as string,
        limit: parseInt(limit as string),
        offset: parseInt(offset as string),
      };

      // Filter by user role
      if (user.role === 'farmer') {
        params.farmerId = userId;
      } else {
        params.buyerId = userId;
      }

      const requests = await storage.getCropRequests(params);
      res.json(requests);
    } catch (error) {
      console.error("Error fetching crop requests:", error);
      res.status(500).json({ message: "Failed to fetch crop requests" });
    }
  });

  app.post('/api/crop-requests', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      
      // Get the crop to find the farmer
      const crop = await storage.getCrop(req.body.cropId);
      if (!crop) {
        return res.status(404).json({ message: "Crop not found" });
      }

      const requestData = insertCropRequestSchema.parse({
        ...req.body,
        buyerId: userId,
        farmerId: crop.farmerId,
      });

      const request = await storage.createCropRequest(requestData);
      res.json(request);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid request data", errors: error.errors });
      }
      console.error("Error creating crop request:", error);
      res.status(500).json({ message: "Failed to create crop request" });
    }
  });

  app.patch('/api/crop-requests/:id', isAuthenticated, async (req: any, res) => {
    try {
      const id = parseInt(req.params.id);
      const userId = req.user.claims.sub;
      
      // Check if user is involved in this request
      const existingRequest = await storage.getCropRequest(id);
      if (!existingRequest || 
          (existingRequest.farmerId !== userId && existingRequest.buyerId !== userId)) {
        return res.status(403).json({ message: "Unauthorized to update this request" });
      }

      const updateData = updateCropRequestSchema.parse(req.body);
      const request = await storage.updateCropRequest(id, updateData);
      res.json(request);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid request data", errors: error.errors });
      }
      console.error("Error updating crop request:", error);
      res.status(500).json({ message: "Failed to update crop request" });
    }
  });

  // Message routes
  app.get('/api/messages', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const {
        otherUserId,
        requestId,
        limit = '50',
        offset = '0'
      } = req.query;

      const params: any = {
        limit: parseInt(limit as string),
        offset: parseInt(offset as string),
      };

      if (otherUserId) {
        // Get conversation between two users
        const messages = await storage.getMessages({
          ...params,
          senderId: userId,
          receiverId: otherUserId as string,
        });
        
        const otherMessages = await storage.getMessages({
          ...params,
          senderId: otherUserId as string,
          receiverId: userId,
        });

        // Combine and sort messages
        const allMessages = [...messages, ...otherMessages]
          .sort((a, b) => new Date(a.createdAt || 0).getTime() - new Date(b.createdAt || 0).getTime());
        
        res.json(allMessages);
      } else if (requestId) {
        params.requestId = parseInt(requestId as string);
        const messages = await storage.getMessages(params);
        res.json(messages);
      } else {
        // Get all messages for user
        const sent = await storage.getMessages({ ...params, senderId: userId });
        const received = await storage.getMessages({ ...params, receiverId: userId });
        res.json({ sent, received });
      }
    } catch (error) {
      console.error("Error fetching messages:", error);
      res.status(500).json({ message: "Failed to fetch messages" });
    }
  });

  app.post('/api/messages', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const messageData = insertMessageSchema.parse({
        ...req.body,
        senderId: userId,
      });

      const message = await storage.createMessage(messageData);
      res.json(message);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid message data", errors: error.errors });
      }
      console.error("Error creating message:", error);
      res.status(500).json({ message: "Failed to create message" });
    }
  });

  app.patch('/api/messages/mark-read', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { senderId } = req.body;

      await storage.markMessagesAsRead(userId, senderId);
      res.json({ message: "Messages marked as read" });
    } catch (error) {
      console.error("Error marking messages as read:", error);
      res.status(500).json({ message: "Failed to mark messages as read" });
    }
  });

  // Dashboard stats
  app.get('/api/dashboard/stats', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      const stats = await storage.getDashboardStats(userId, user.role);
      res.json(stats);
    } catch (error) {
      console.error("Error fetching dashboard stats:", error);
      res.status(500).json({ message: "Failed to fetch dashboard stats" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
