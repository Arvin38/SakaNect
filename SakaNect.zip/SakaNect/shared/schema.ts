import {
  pgTable,
  text,
  varchar,
  timestamp,
  jsonb,
  index,
  serial,
  integer,
  decimal,
  boolean,
  pgEnum
} from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Session storage table (required for Replit Auth)
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User role enum
export const userRoleEnum = pgEnum("user_role", ["farmer", "buyer"]);

// Transaction status enum
export const transactionStatusEnum = pgEnum("transaction_status", [
  "pending", 
  "approved", 
  "declined", 
  "completed", 
  "cancelled"
]);

// Transaction type enum
export const transactionTypeEnum = pgEnum("transaction_type", [
  "sale", 
  "barter", 
  "donation"
]);

// Crop status enum
export const cropStatusEnum = pgEnum("crop_status", [
  "available",
  "limited", 
  "sold",
  "reserved"
]);

// User storage table (required for Replit Auth)
export const users = pgTable("users", {
  id: varchar("id").primaryKey().notNull(),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  role: userRoleEnum("role").notNull().default("buyer"),
  phoneNumber: varchar("phone_number"),
  location: varchar("location"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Crops table
export const crops = pgTable("crops", {
  id: serial("id").primaryKey(),
  name: varchar("name").notNull(),
  description: text("description"),
  price: decimal("price", { precision: 10, scale: 2 }),
  quantity: integer("quantity").notNull(),
  unit: varchar("unit").notNull().default("kg"),
  category: varchar("category").notNull(),
  imageUrl: varchar("image_url"),
  location: varchar("location").notNull(),
  farmerId: varchar("farmer_id").notNull().references(() => users.id),
  status: cropStatusEnum("status").notNull().default("available"),
  transactionType: transactionTypeEnum("transaction_type").notNull().default("sale"),
  barterFor: varchar("barter_for"), // What they want in exchange for barter
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Crop requests/transactions table
export const cropRequests = pgTable("crop_requests", {
  id: serial("id").primaryKey(),
  cropId: integer("crop_id").notNull().references(() => crops.id),
  buyerId: varchar("buyer_id").notNull().references(() => users.id),
  farmerId: varchar("farmer_id").notNull().references(() => users.id),
  requestedQuantity: integer("requested_quantity").notNull(),
  offeredPrice: decimal("offered_price", { precision: 10, scale: 2 }),
  barterOffer: varchar("barter_offer"), // What buyer offers for barter
  contactNumber: varchar("contact_number"),
  notes: text("notes"),
  status: transactionStatusEnum("status").notNull().default("pending"),
  transactionType: transactionTypeEnum("transaction_type").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Messages table for communication
export const messages = pgTable("messages", {
  id: serial("id").primaryKey(),
  senderId: varchar("sender_id").notNull().references(() => users.id),
  receiverId: varchar("receiver_id").notNull().references(() => users.id),
  requestId: integer("request_id").references(() => cropRequests.id),
  content: text("content").notNull(),
  isRead: boolean("is_read").notNull().default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

// Relations
export const usersRelations = relations(users, ({ many }) => ({
  crops: many(crops),
  sentRequests: many(cropRequests, { relationName: "buyer_requests" }),
  receivedRequests: many(cropRequests, { relationName: "farmer_requests" }),
  sentMessages: many(messages, { relationName: "sent_messages" }),
  receivedMessages: many(messages, { relationName: "received_messages" }),
}));

export const cropsRelations = relations(crops, ({ one, many }) => ({
  farmer: one(users, {
    fields: [crops.farmerId],
    references: [users.id],
  }),
  requests: many(cropRequests),
}));

export const cropRequestsRelations = relations(cropRequests, ({ one, many }) => ({
  crop: one(crops, {
    fields: [cropRequests.cropId],
    references: [crops.id],
  }),
  buyer: one(users, {
    fields: [cropRequests.buyerId],
    references: [users.id],
    relationName: "buyer_requests",
  }),
  farmer: one(users, {
    fields: [cropRequests.farmerId],
    references: [users.id],
    relationName: "farmer_requests",
  }),
  messages: many(messages),
}));

export const messagesRelations = relations(messages, ({ one }) => ({
  sender: one(users, {
    fields: [messages.senderId],
    references: [users.id],
    relationName: "sent_messages",
  }),
  receiver: one(users, {
    fields: [messages.receiverId],
    references: [users.id],
    relationName: "received_messages",
  }),
  request: one(cropRequests, {
    fields: [messages.requestId],
    references: [cropRequests.id],
  }),
}));

// Insert schemas
export const insertUserSchema = createInsertSchema(users).omit({
  createdAt: true,
  updatedAt: true,
});

export const insertCropSchema = createInsertSchema(crops).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertCropRequestSchema = createInsertSchema(cropRequests).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertMessageSchema = createInsertSchema(messages).omit({
  id: true,
  createdAt: true,
});

// Update schemas
export const updateCropSchema = insertCropSchema.partial();
export const updateCropRequestSchema = insertCropRequestSchema.partial();

// Types
export type UpsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type Crop = typeof crops.$inferSelect;
export type InsertCrop = z.infer<typeof insertCropSchema>;
export type UpdateCrop = z.infer<typeof updateCropSchema>;
export type CropRequest = typeof cropRequests.$inferSelect;
export type InsertCropRequest = z.infer<typeof insertCropRequestSchema>;
export type UpdateCropRequest = z.infer<typeof updateCropRequestSchema>;
export type Message = typeof messages.$inferSelect;
export type InsertMessage = z.infer<typeof insertMessageSchema>;

// Extended types with relations
export type CropWithFarmer = Crop & {
  farmer: User;
};

export type CropRequestWithDetails = CropRequest & {
  crop: CropWithFarmer;
  buyer: User;
  farmer: User;
};

export type MessageWithSender = Message & {
  sender: User;
};
